package com.deniscerri.ytdl.util

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.deniscerri.ytdl.R
import org.xmlpull.v1.XmlPullParser
import java.util.Locale

object LocaleUtil {
    private const val ANDROID_NS = "http://schemas.android.com/apk/res/android"

    fun currentLocale(): Locale {
        return AppCompatDelegate.getApplicationLocales()[0] ?: Locale.getDefault()
    }

    /** True when the user picked a language for this app instead of following the system */
    fun isOverridden(): Boolean {
        return !AppCompatDelegate.getApplicationLocales().isEmpty
    }

    /** Pass null to follow the system language */
    fun setAppLocale(locale: Locale?) {
        AppCompatDelegate.setApplicationLocales(
            if (locale == null) LocaleListCompat.getEmptyLocaleList()
            else LocaleListCompat.create(locale)
        )
    }

    /** Locales the app ships translations for */
    fun supportedLocales(context: Context): List<Locale> {
        val locales = mutableListOf<Locale>()
        runCatching {
            // YTindir: our own curated list (the manifest's localeConfig), not every values-* folder
            context.resources.getXml(R.xml.locales_config).use { parser ->
                while (parser.next() != XmlPullParser.END_DOCUMENT) {
                    if (parser.eventType == XmlPullParser.START_TAG && parser.name == "locale") {
                        parser.getAttributeValue(ANDROID_NS, "name")?.let {
                            locales.add(Locale.forLanguageTag(it))
                        }
                    }
                }
            }
        }
        return locales.distinct()
    }

    /** Name of the locale written in its own language. Region is only shown when it tells variants apart */
    fun displayName(locale: Locale, supported: List<Locale>): String {
        val hasVariants = supported.count { it.language == locale.language } > 1
        val name = if (hasVariants) locale.getDisplayName(locale) else locale.getDisplayLanguage(locale)
        return name.replaceFirstChar { it.titlecase(locale) }
    }
}
