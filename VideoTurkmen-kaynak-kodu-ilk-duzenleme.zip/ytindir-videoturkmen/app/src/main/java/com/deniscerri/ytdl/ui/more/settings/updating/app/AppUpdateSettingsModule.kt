package com.deniscerri.ytdl.ui.more.settings.updating.app

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.preference.Preference
import androidx.preference.PreferenceManager
import com.deniscerri.ytdl.BuildConfig
import com.deniscerri.ytdl.R
import com.deniscerri.ytdl.database.models.GithubRelease
import com.deniscerri.ytdl.database.viewmodel.SettingsViewModel
import com.deniscerri.ytdl.ui.more.settings.SettingHost
import com.deniscerri.ytdl.ui.more.settings.SettingModule
import com.deniscerri.ytdl.ui.more.settings.updating.UpdateChannelPreference
import com.deniscerri.ytdl.ui.more.settings.updating.UpdateStatusCardPreference
import com.deniscerri.ytdl.util.UiUtil
import com.deniscerri.ytdl.util.UpdateUtil
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File


object AppUpdateSettingsModule : SettingModule {
    private val canUpdateApp = UpdateUtil.APP_UPDATES_ENABLED

    override fun bindLogic(pref: Preference, host: SettingHost) {
        val context = pref.context
        val preferences = PreferenceManager.getDefaultSharedPreferences(context)

        when(pref.key) {
            "app_status_card" -> {
                (pref as UpdateStatusCardPreference).apply {
                    version = BuildConfig.VERSION_NAME
                    showButton = canUpdateApp
                    buttonText = null
                    status = restingStatus(preferences.getBoolean("update_app", true))
                    onButtonClick = { checkForUpdates(context, host, preferences) }
                    refreshDetails(context, this, preferences)
                }
            }
            "app_channel" -> {
                // YTindir: there is only one release channel
                host.findPref("app_update_channel_category")?.isVisible = false
                (pref as UpdateChannelPreference).apply {
                    isVisible = false
                    setChannels(listOf(
                        "stable" to context.getString(R.string.channel_stable),
                        "beta" to context.getString(R.string.channel_beta)
                    ))
                    selectedChannel = if (preferences.getBoolean("update_beta", false)) "beta" else "stable"
                    onChannelSelected = { value ->
                        preferences.edit { putBoolean("update_beta", value == "beta") }
                        (host.findPref("app_status_card") as? UpdateStatusCardPreference)?.let { refreshDetails(context, it, preferences) }
                        checkForUpdates(context, host, preferences)
                    }
                }
            }
            "update_app" -> {
                pref.isVisible = canUpdateApp
                pref.setOnPreferenceChangeListener { _, newValue ->
                    (host.findPref("app_status_card") as? UpdateStatusCardPreference)?.apply {
                        if (status == UpdateStatusCardPreference.Status.UP_TO_DATE || status == UpdateStatusCardPreference.Status.UNKNOWN) {
                            status = restingStatus(newValue as Boolean)
                        }
                    }
                    true
                }
            }
            "changelog" -> {
                pref.setOnPreferenceClickListener {
                    host.requestNavigate(R.id.changeLogFragment)
                    false
                }
            }
        }
    }

    private fun channelDescription(context: Context, preferences: SharedPreferences) =
        context.getString(if (preferences.getBoolean("update_beta", false)) R.string.channel_stable else R.string.channel_beta)

    private fun refreshDetails(context: Context, card: UpdateStatusCardPreference, preferences: SharedPreferences) {
        val architecture = File(context.applicationInfo.nativeLibraryDir).name
        // store builds update through their store, so there is no channel or check time to show
        if (!canUpdateApp) {
            card.subtitle = architecture
            card.detail = null
            return
        }
        val channel = context.getString(if (preferences.getBoolean("update_beta", false)) R.string.channel_beta else R.string.channel_stable)
        card.subtitle = "$architecture · $channel"
        card.detail = UpdateStatusCardPreference.buildDetail(context, preferences.getLong(UpdateUtil.APP_LAST_CHECK_KEY, 0L))
    }

    private fun restingStatus(autoCheck: Boolean) =
        if (canUpdateApp && autoCheck) UpdateStatusCardPreference.Status.UP_TO_DATE else UpdateStatusCardPreference.Status.UNKNOWN

    private fun checkForUpdates(context: Context, host: SettingHost, preferences: SharedPreferences) {
        val card = host.findPref("app_status_card") as? UpdateStatusCardPreference
        val updateUtil = UpdateUtil(context)

        host.hostLifecycleOwner.lifecycleScope.launch {
            card?.buttonText = null
            card?.latestVersion = null
            card?.status = UpdateStatusCardPreference.Status.CHECKING

            val res = withContext(Dispatchers.IO){
                updateUtil.tryGetNewVersion()
            }

            card?.let { refreshDetails(context, it, preferences) }

            if (res.isSuccess) {
                val release = res.getOrNull()!!
                card?.apply {
                    latestVersion = release.tag_name.removePrefix("v")
                    status = UpdateStatusCardPreference.Status.UPDATE_AVAILABLE
                    buttonText = "${context.getString(R.string.update)} (${release.tag_name})"
                    onButtonClick = { showUpdateDialog(release, updateUtil, host, preferences) }
                }
                showUpdateDialog(release, updateUtil, host, preferences)
            } else if (res.exceptionOrNull()?.message == context.getString(R.string.you_are_in_latest_version)) {
                card?.status = UpdateStatusCardPreference.Status.UP_TO_DATE
            } else {
                card?.status = UpdateStatusCardPreference.Status.ERROR
                val view = host.hostView
                if (view != null && view.isAttachedToWindow) {
                    Snackbar.make(view, res.exceptionOrNull()?.message ?: context.getString(R.string.network_error), Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showUpdateDialog(release: GithubRelease, updateUtil: UpdateUtil, host: SettingHost, preferences: SharedPreferences) {
        val settingsViewModel = ViewModelProvider(host.hostViewModelStoreOwner)[SettingsViewModel::class.java]
        host.hostLifecycleOwner.lifecycleScope.launch {
            if (preferences.getBoolean("automatic_backup", false)) {
                withContext(Dispatchers.IO){
                    settingsViewModel.backup()
                }
            }
            UiUtil.showNewAppUpdateDialog(release, host.getHostContext(), updateUtil, host.hostLifecycleOwner, preferences, host.getAppInstallLauncher())
        }
    }
}
