package com.deniscerri.ytdl.ui.home

import com.squareup.picasso.Picasso
import androidx.core.widget.ImageViewCompat
import android.widget.TextView
import android.widget.ImageView
import com.google.android.material.card.MaterialCardView
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Context.CLIPBOARD_SERVICE
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Patterns
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import android.view.View.GONE
import android.view.View.OnClickListener
import android.view.View.OnTouchListener
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.ActionMode
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.os.bundleOf
import androidx.core.view.children
import androidx.core.view.forEach
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.deniscerri.ytdl.MainActivity
import com.deniscerri.ytdl.R
import com.deniscerri.ytdl.database.enums.DownloadType
import com.deniscerri.ytdl.database.models.ResultItem
import com.deniscerri.ytdl.database.models.SearchSuggestionItem
import com.deniscerri.ytdl.database.models.SearchSuggestionType
import com.deniscerri.ytdl.database.viewmodel.DownloadCardViewModel
import com.deniscerri.ytdl.database.viewmodel.DownloadViewModel
import com.deniscerri.ytdl.database.viewmodel.HistoryViewModel
import com.deniscerri.ytdl.database.viewmodel.ResultViewModel
import com.deniscerri.ytdl.ui.adapter.HomeAdapter
import com.deniscerri.ytdl.ui.adapter.SearchSuggestionsAdapter
import com.deniscerri.ytdl.ui.more.cookies.WebViewActivity
import com.deniscerri.ytdl.util.Extensions.enableFastScroll
import com.deniscerri.ytdl.util.Extensions.isURL
import com.deniscerri.ytdl.util.NotificationUtil
import com.deniscerri.ytdl.util.ThemeUtil
import com.deniscerri.ytdl.core.RuntimeManager
import com.deniscerri.ytdl.util.UiUtil
import com.facebook.shimmer.ShimmerFrameLayout
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.android.material.search.SearchBar
import com.google.android.material.search.SearchView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.Lifecycle
import androidx.paging.LoadState
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.badge.ExperimentalBadgeUtils
import com.google.android.material.badge.BadgeUtils
import com.google.android.material.badge.BadgeDrawable
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL


class HomeFragment : Fragment(), HomeAdapter.OnItemClickListener, SearchSuggestionsAdapter.OnItemClickListener, OnClickListener,
    FailedFetchesBottomSheetDialog.Listener, UpdatesDialog.Listener {
    private var inputQueries: MutableList<String>? = null
    private lateinit var homeAdapter: HomeAdapter
    private var totalCount: Int = 0
    private var firstResult: ResultItem? = null
    private var searchSuggestionsAdapter: SearchSuggestionsAdapter? = null
    private var queriesConstraint: ConstraintLayout? = null

    private var downloadSelectedFab: ExtendedFloatingActionButton? = null
    private var downloadAllFab: ExtendedFloatingActionButton? = null
    private var clipboardFab: ExtendedFloatingActionButton? = null
    private var clipboardCard: MaterialCardView? = null
    private var homeFabs: LinearLayout? = null
    private var notificationUtil: NotificationUtil? = null
    private var downloadQueue: ArrayList<ResultItem>? = null

    private lateinit var playlistNameFilterScrollView: HorizontalScrollView
    private lateinit var playlistNameFilterChipGroup: ChipGroup

    private lateinit var resultViewModel : ResultViewModel
    private lateinit var downloadViewModel : DownloadViewModel
    private lateinit var historyViewModel : HistoryViewModel
    private lateinit var downloadCardViewModel : DownloadCardViewModel

    private var fragmentView: View? = null
    private var activity: Activity? = null
    private var mainActivity: MainActivity? = null
    private var fragmentContext: Context? = null
    private var layoutinflater: LayoutInflater? = null
    private var shimmerCards: ShimmerFrameLayout? = null
    private var searchBar: SearchBar? = null
    private var searchView: SearchView? = null
    private var providersChipGroup: ChipGroup? = null
    private var chipGroupDivider: View? = null
    private var queriesChipGroup: ChipGroup? = null
    private var recyclerView: RecyclerView? = null
    private var searchSuggestionsRecyclerView: RecyclerView? = null
    private var uiHandler: Handler? = null
    private var quickLaunchSheet = false
    private var sharedPreferences: SharedPreferences? = null
    private var actionMode: ActionMode? = null
    private var appBarLayout: AppBarLayout? = null
    private var materialToolbar: MaterialToolbar? = null
    private var loadingItems: Boolean = false
    private var queryList = mutableListOf<String>()

    private var showDownloadAllFab: Boolean = false
    private var showClipboardFab: Boolean = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        fragmentView = inflater.inflate(R.layout.fragment_home, container, false)
        activity = getActivity()
        mainActivity = activity as MainActivity?
        quickLaunchSheet = false
        notificationUtil = NotificationUtil(requireContext())
        return fragmentView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        fragmentContext = context
        layoutinflater = LayoutInflater.from(context)
        uiHandler = Handler(Looper.getMainLooper())

        downloadViewModel = ViewModelProvider(requireActivity())[DownloadViewModel::class.java]
        historyViewModel = ViewModelProvider(this)[HistoryViewModel::class.java]
        downloadCardViewModel = ViewModelProvider(requireActivity())[DownloadCardViewModel::class.java]

        downloadQueue = ArrayList()

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(requireContext())

        //initViews
        searchBar = view.findViewById(R.id.search_bar)
        searchView = view.findViewById(R.id.search_view)
        appBarLayout = view.findViewById(R.id.home_appbarlayout)
        materialToolbar = view.findViewById(R.id.home_toolbar)
        queriesChipGroup = view.findViewById(R.id.queries)
        queriesConstraint = view.findViewById(R.id.queries_constraint)
        homeFabs = view.findViewById(R.id.home_fabs)
        downloadSelectedFab = homeFabs!!.findViewById(R.id.download_selected_fab)
        downloadAllFab = homeFabs!!.findViewById(R.id.download_all_fab)
        clipboardFab = homeFabs!!.findViewById(R.id.copied_url_fab)
        clipboardCard = homeFabs!!.findViewById(R.id.clipboard_card)
        playlistNameFilterScrollView = view.findViewById(R.id.playlist_selection_chips_scrollview)
        playlistNameFilterChipGroup = view.findViewById(R.id.playlist_selection_chips)

        runCatching { materialToolbar!!.title = ThemeUtil.getStyledAppName(requireContext()) }

        homeAdapter =
            HomeAdapter(
                this,
                requireActivity()
            )
        recyclerView = view.findViewById(R.id.recyclerViewHome)
        recyclerView?.layoutManager = GridLayoutManager(context, resources.getInteger(R.integer.grid_size))
        recyclerView?.adapter = homeAdapter
        recyclerView?.enableFastScroll()

        shimmerCards = view.findViewById(R.id.shimmer_results_framelayout)



        searchSuggestionsAdapter = SearchSuggestionsAdapter(
                this,
                requireActivity()
            )
        searchSuggestionsRecyclerView = view.findViewById(R.id.search_suggestions_recycler)
        searchSuggestionsRecyclerView?.layoutManager = LinearLayoutManager(context)
        searchSuggestionsRecyclerView?.adapter = searchSuggestionsAdapter
        searchSuggestionsRecyclerView?.itemAnimator = null
        searchSuggestionsRecyclerView?.isNestedScrollingEnabled = false

        val progressBar = view.findViewById<View>(R.id.progress)

        resultViewModel = ViewModelProvider(requireActivity())[ResultViewModel::class.java]

        initToolbarMenu()

        lifecycleScope.launch {
            resultViewModel.paginatedItems.collectLatest {
                homeAdapter.submitData(it)
            }
        }

        // YTindir: sorting chips, shown when the results know their views or upload dates
        val sortScroll = view.findViewById<HorizontalScrollView>(R.id.result_sort_scrollview)
        val sortChips = view.findViewById<ChipGroup>(R.id.result_sort_chips)
        sortChips.children.forEach { c ->
            val chip = c as Chip
            chip.isChecked = chip.tag == resultViewModel.sortOrder.value
            chip.setOnClickListener {
                resultViewModel.setSortOrder(chip.tag as String)
                recyclerView?.scrollToPosition(0)
            }
        }
        lifecycleScope.launch {
            combine(resultViewModel.sortableCount, resultViewModel.totalCount) { sortable, total -> sortable > 1 && total > 1 }
                .collectLatest { show ->
                    sortScroll.isVisible = show
                    if (!show && resultViewModel.sortOrder.value != "relevance") {
                        resultViewModel.setSortOrder("relevance")
                        (sortChips.findViewWithTag<Chip>("relevance"))?.isChecked = true
                    }
                }
        }

        homeAdapter.addLoadStateListener { loadStates ->
            val isNotLoading = loadStates.refresh is LoadState.NotLoading
            if (isNotLoading) {
                val size = resultViewModel.totalCount.value;
                val firstResult = resultViewModel.firstResult.value;

                progressBar.isVisible = loadingItems && size > 0
                if(resultViewModel.repository.itemCount.value > 1 || resultViewModel.repository.itemCount.value == -1){
                    showDownloadAllFab = size > 1 && firstResult!!.playlistTitle.isNotEmpty() && !loadingItems
                    downloadAllFab!!.isVisible = showDownloadAllFab
                }else if (resultViewModel.repository.itemCount.value == 1){
                    if (sharedPreferences!!.getBoolean("download_card", true)){
                        if(size == 1 && quickLaunchSheet && parentFragmentManager.findFragmentByTag("downloadSingleSheet") == null){
                            showSingleDownloadSheet(
                                firstResult!!,
                                DownloadType.valueOf(sharedPreferences!!.getString("preferred_download_type", "video")!!)
                            )
                        }
                    }
                }else{
                    showDownloadAllFab = false
                    downloadAllFab!!.visibility = GONE
                }
                quickLaunchSheet = true
            }
        }

        lifecycleScope.launch {
            resultViewModel.totalCount.collectLatest {
                totalCount = it
                searchBar?.menu?.findItem(R.id.select_range)?.isVisible = it >= 3
            }
        }

        lifecycleScope.launch {
            resultViewModel.firstResult.collectLatest {
                firstResult = it
            }
        }

        lifecycleScope.launch {
            resultViewModel.playlistResults.collectLatest {
                updateMultiplePlaylistResults(it
                    .filter { it2 -> it2 != "YTDLNIS_SEARCH" }
                )
            }
        }

        initMenu()
        downloadSelectedFab?.tag = "downloadSelected"
        downloadSelectedFab?.setOnClickListener(this)
        downloadAllFab?.tag = "downloadAll"
        downloadAllFab?.setOnClickListener(this)

        if (arguments?.getString("url") != null){
            val url = requireArguments().getString("url")
            if (inputQueries == null) inputQueries = mutableListOf()
            searchBar?.setText(url)
            val argList = url!!.split("\n").filter { it.isURL() }.toMutableList()
            argList.removeAll(listOf("", null))
            inputQueries!!.addAll(argList)
        }

        if (inputQueries != null) {
            lifecycleScope.launch(Dispatchers.IO){
                resultViewModel.deleteAll()
                resultViewModel.parseQueries(inputQueries!!){}
                inputQueries = null
            }
        }

        searchView?.addTransitionListener { _, _, newState ->
            if (newState == SearchView.TransitionState.SHOWING){
                mainActivity?.hideBottomNavigation()
            }else if (newState == SearchView.TransitionState.HIDING){
                mainActivity?.showBottomNavigation()
            } else if (newState == SearchView.TransitionState.HIDDEN) {
                appBarLayout?.setExpanded(true, true)
            }
        }

        mainActivity?.onBackPressedDispatcher?.addCallback(this) {
            if (searchView?.isShowing == true) {
                searchView?.hide()
            }else{
                mainActivity?.finishAffinity()
            }
        }

        lifecycleScope.launch {
            launch{
                resultViewModel.uiState.collectLatest { res ->
                    if (res.errorMessage != null){
                        val isSingleQueryAndURL = queryList.size == 1 && Patterns.WEB_URL.matcher(queryList.first()).matches()

                        runCatching {
                            UiUtil.handleNoResults(requireActivity(), res.errorMessage!!,
                                url = if (isSingleQueryAndURL) queryList.first() else null,
                                continueAnyway = isSingleQueryAndURL,
                                continued = {
                                    resultViewModel.removeFailedQuery(queryList.first())
                                    onDownloadAnyway(queryList.first())
                                },
                                cookieFetch = {
                                    val myIntent = Intent(requireContext(), WebViewActivity::class.java)
                                    myIntent.putExtra("url", "https://${URL(queryList.first()).host}")
                                    cookiesFetchedResultLauncher.launch(myIntent)
                                },
                                closed = {}
                            )
                        }
                        resultViewModel.uiState.update {it.copy(errorMessage  = null) }
                    }

                    loadingItems = res.processing
                    progressBar.isVisible = loadingItems && totalCount > 0
                    if (res.processing){
                        recyclerView?.setPadding(0,0,0,0)
                        shimmerCards!!.startShimmer()
                        shimmerCards!!.visibility = VISIBLE
                    }else{
                        recyclerView?.setPadding(0,0,0,100)
                        shimmerCards!!.stopShimmer()
                        shimmerCards!!.visibility = GONE

                        showDownloadAllFab = totalCount > 1 && firstResult?.playlistTitle.orEmpty().isNotEmpty()
                        downloadAllFab!!.isVisible = showDownloadAllFab
                    }
                }
            }
        }

        lifecycleScope.launch {
            launch{
                downloadViewModel.alreadyExistsUiState.collectLatest { res ->
                    if (res.isNotEmpty()){
                        withContext(Dispatchers.Main){
                            val bundle = bundleOf(
                                Pair("duplicates", ArrayList(res))
                            )
                            delay(500)
                            findNavController().navigate(R.id.downloadsAlreadyExistDialog, bundle)
                        }
                        downloadViewModel.alreadyExistsUiState.value = mutableListOf()
                    }
                }
            }
        }

    }

    private var cookiesFetchedResultLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            sharedPreferences?.edit()?.putBoolean("use_cookies", true)?.apply()
            startSearch()
        }
    }

    override fun onResume() {
        super.onResume()
        if(arguments?.getString("url") == null){
            if (!resultViewModel.uiState.value.processing){
                resultViewModel.checkTrending()
            }
        }else{
            arguments?.remove("url")
        }

        if (arguments?.getBoolean("showDownloadsWithUpdatedFormats") == true){
            notificationUtil?.cancelDownloadNotification(NotificationUtil.FORMAT_UPDATING_FINISHED_NOTIFICATION_ID)
            arguments?.remove("showDownloadsWithUpdatedFormats")
            CoroutineScope(Dispatchers.IO).launch {
                val ids = arguments?.getLongArray("downloadIds") ?: return@launch
                downloadViewModel.turnDownloadItemsToProcessingDownloads(ids.toList(), deleteExisting = true)
                withContext(Dispatchers.Main){
                    findNavController().navigate(R.id.downloadMultipleBottomSheetDialog2)
                }
            }
        }
        
        if(arguments?.getBoolean("search") == true){
            arguments?.remove("search")
            requireView().post {
                searchBar?.performClick()
            }
        }

        if (searchView?.currentTransitionState == SearchView.TransitionState.SHOWN){
            updateSearchViewItems(searchView?.editText?.text.toString())
        }

        requireView().post {
            checkClipboard().apply {
                this?.apply {
                    showClipboardFab = this.isNotEmpty()
                    bindClipboardCard(this)
                    setClipboardVisible(showClipboardFab)
                    clipboardFab?.setOnClickListener {
                        if (this.size == 1){
                            searchView?.setText(this.first())
                            showClipboardFab = false
                            setClipboardVisible(false)
                            initSearch(searchView!!)
                        }else{
                            searchBar?.performClick()
                            lifecycleScope.launch {
                                withContext(Dispatchers.IO){
                                    delay(500)
                                }
                                this@apply.forEach {
                                    onSearchSuggestionAdd(it)
                                }
                            }
                        }
                    }
                }

                lifecycleScope.launch {
                    clipboardFab?.extend()
                    delay(1000)
                    clipboardFab?.shrink()
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initMenu() {
        val queriesConstraint = requireView().findViewById<ConstraintLayout>(R.id.queries_constraint)
        val queriesInitStartBtn = queriesConstraint.findViewById<MaterialButton>(R.id.init_search_query)
        val isRightToLeft = resources.getBoolean(R.bool.is_right_to_left)

        providersChipGroup = searchView!!.findViewById(R.id.providers)
        val providers = resources.getStringArray(R.array.search_engines)
        val providersValues = resources.getStringArray(R.array.search_engines_values).toMutableList()

        for(i in providersValues.indices){
            val provider = providers[i]
            val providerValue = providersValues[i]
            val tmp = layoutinflater!!.inflate(R.layout.filter_chip, providersChipGroup, false) as Chip
            tmp.text = provider
            tmp.id = i
            tmp.tag = providersValues[i]

            tmp.setOnClickListener {
                val editor = sharedPreferences?.edit()
                editor?.putString("search_engine", providerValue)
                editor?.apply()

            }

            providersChipGroup?.addView(tmp)
        }

        chipGroupDivider = requireView().findViewById(R.id.chipGroupDivider)

        searchView!!.addTransitionListener { _, _, newState ->
            if (newState == SearchView.TransitionState.SHOWN) {
                val currentProvider = sharedPreferences?.getString("search_engine", "ytsearch")
                providersChipGroup?.children?.forEach {
                    val tmp = providersChipGroup?.findViewById<Chip>(it.id)
                    if (tmp?.tag?.equals(currentProvider) == true) {
                        tmp.isChecked = true
                        return@forEach
                    }
                }

                if (Patterns.WEB_URL.matcher(searchBar!!.text.toString()).matches() && searchBar!!.text.isNotBlank()){
                    providersChipGroup?.visibility = GONE
                    chipGroupDivider?.visibility = GONE
                }else{
                    providersChipGroup?.visibility = VISIBLE
                    chipGroupDivider?.visibility = VISIBLE
                }

                updateSearchViewItems(searchView!!.editText.text.toString())
            }
        }

        searchView!!.editText.doAfterTextChanged {
            if (searchView!!.currentTransitionState != SearchView.TransitionState.SHOWN) return@doAfterTextChanged
            updateSearchViewItems(it.toString())
        }

        searchView!!.editText.setOnTouchListener(OnTouchListener { _, event ->
            try{
                val drawableLeft = 0
                val drawableRight = 2
                if (event.action == MotionEvent.ACTION_UP) {
                    if (
                        (isRightToLeft && (event.x < (searchView!!.editText.left - searchView!!.editText.compoundDrawables[drawableLeft].bounds.width()))) ||
                        (!isRightToLeft && (event.x > (searchView!!.editText.right - searchView!!.editText.compoundDrawables[drawableRight].bounds.width())))
                        ){

                        val present = queriesChipGroup!!.children.firstOrNull { (it as Chip).text.toString() == searchView!!.editText.text.toString() }
                        if (present == null) {
                            val chip = layoutinflater!!.inflate(R.layout.input_chip, queriesChipGroup, false) as Chip
                            chip.text = searchView!!.editText.text
                            chip.chipBackgroundColor = ColorStateList.valueOf(MaterialColors.getColor(requireContext(), R.attr.colorSecondaryContainer, Color.BLACK))
                            chip.setOnClickListener {
                                queriesChipGroup!!.removeView(chip)
                                if (queriesChipGroup!!.childCount == 0) queriesConstraint.visibility = GONE
                            }
                            queriesChipGroup!!.addView(chip)
                        }
                        if (queriesChipGroup!!.childCount == 0) queriesConstraint.visibility = GONE
                        else queriesConstraint.visibility = VISIBLE
                        searchView!!.editText.setText("")
                        return@OnTouchListener true

                    }
                }
            }catch (ignored: Exception){}
            false
        })

        searchView!!.editText.setOnEditorActionListener { _, _, _ ->
            initSearch(searchView!!)
            true
        }

        searchBar!!.setOnMenuItemClickListener { m: MenuItem ->
            when (m.itemId) {
                R.id.copy_urls -> {
                    lifecycleScope.launch {
                        val urls = withContext(Dispatchers.IO){
                            resultViewModel.getURLs()
                        }

                        UiUtil.copyToClipboard(urls.distinct().joinToString("\n"), requireActivity())
                    }
                }
                R.id.delete_results -> {
                    resultViewModel.clearResults()
                    searchBar!!.setText("")
                    showDownloadAllFab = false
                    downloadAllFab!!.visibility = GONE
                    downloadSelectedFab!!.visibility = GONE
                }
                R.id.select_range -> {
                    UiUtil.showSelectRangeDialog(requireActivity(), totalCount) { range ->
                        lifecycleScope.launch {
                            val ids = withContext(Dispatchers.IO) {
                                resultViewModel.getAllIds()
                            }
                            val itemsBetween = ids.filterIndexed { index, _ -> index >= range.first && index <= range.second }
                            if (itemsBetween.isEmpty()) return@launch

                            homeAdapter.checkMultipleItems(itemsBetween)
                            if (actionMode == null) actionMode = (getActivity() as AppCompatActivity?)!!.startSupportActionMode(contextualActionBar)
                            actionMode?.title = "${itemsBetween.size} ${getString(R.string.selected)}"
                            actionMode?.menu?.findItem(R.id.select_between)?.isVisible = false
                        }
                    }
                }
                R.id.delete_search -> {
                    resultViewModel.deleteAllSearchQueryHistory()
                    searchSuggestionsAdapter?.submitList(listOf())
                }
            }
            true
        }
        queriesChipGroup!!.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (queriesChipGroup!!.childCount == 0) queriesConstraint.visibility = GONE
            else queriesConstraint.visibility = VISIBLE
        }

        queriesInitStartBtn.setOnClickListener {
            initSearch(searchView!!)
        }
    }

    @SuppressLint("InflateParams")
    private fun updateSearchViewItems(searchQuery: String) = lifecycleScope.launch(Dispatchers.Main) {
        lifecycleScope.launch {
            if (searchView!!.editText.text.isEmpty()){
                searchView!!.editText.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0)
            }else{
                searchView!!.editText.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_plus, 0)
            }

            val combinedList = mutableListOf<SearchSuggestionItem>()

            val history = withContext(Dispatchers.IO){
                resultViewModel.getSearchHistory().map { it.query }.filter { it.contains(searchQuery, ignoreCase = true) }
            }.map {
                SearchSuggestionItem(it, SearchSuggestionType.HISTORY)
            }
            val suggestions = if (sharedPreferences!!.getBoolean("search_suggestions", false)){
                withContext(Dispatchers.IO){
                    resultViewModel.getSearchSuggestions(searchQuery)
                }
            }else{
                emptyList()
            }.map {
                SearchSuggestionItem(it, SearchSuggestionType.SUGGESTION)
            }

            combinedList.addAll(history)
            combinedList.addAll(suggestions)

            val url = checkClipboard()
            url?.apply {
                var alreadyHasThem = this.all { queriesChipGroup?.children?.any { c -> (c as Chip).text.contains(it) } == true }
                if (this.isNotEmpty() && !alreadyHasThem){
                    combinedList.add(0, SearchSuggestionItem(this.joinToString("\n"), SearchSuggestionType.CLIPBOARD))
                }
            }

            searchSuggestionsAdapter?.submitList(combinedList)

//            history.forEach { s ->
//                val v = LayoutInflater.from(fragmentContext).inflate(R.layout.search_suggestion_item, null)
//                val textView = v.findViewById<TextView>(R.id.suggestion_text)
//                textView.text = s
//                textView.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_restore, 0, 0, 0)
//                Handler(Looper.getMainLooper()).post {
//                    searchHistoryLinearLayout!!.addView(
//                        v
//                    )
//                }
//                textView.setOnClickListener {
//                    searchView!!.setText(s)
//                    initSearch(searchView!!)
//                }
//                textView.setOnLongClickListener {
//                    val deleteDialog = MaterialAlertDialogBuilder(requireContext())
//                    deleteDialog.setTitle(getString(R.string.you_are_going_to_delete) + " \"" + s + "\"!")
//                    deleteDialog.setNegativeButton(getString(R.string.cancel)) { dialogInterface: DialogInterface, _: Int -> dialogInterface.cancel() }
//                    deleteDialog.setPositiveButton(getString(R.string.ok)) { _: DialogInterface?, _: Int ->
//                        searchHistoryLinearLayout!!.removeView(v)
//                        resultViewModel.removeSearchQueryFromHistory(s)
//                    }
//                    deleteDialog.show()
//                    true
//                }
//
//                val mb = v.findViewById<ImageButton>(R.id.set_search_query_button)
//                mb.setOnClickListener {
//                    searchView!!.editText.setText(s)
//                    searchView!!.editText.setSelection(searchView!!.editText.length())
//                }
//            }
//            searchHistoryLinearLayout!!.isVisible = history.isNotEmpty()
//            if (linkYouCopied.findViewById<TextView>(R.id.suggestion_text).text.isNotEmpty()){
//                linkYouCopied.visibility = VISIBLE
//                setClipboardVisible(true)
//            }
//
//            suggestions.forEach { s ->
//                val v = LayoutInflater.from(fragmentContext)
//                    .inflate(R.layout.search_suggestion_item, null)
//                val textView = v.findViewById<TextView>(R.id.suggestion_text)
//                textView.text = s
//                Handler(Looper.getMainLooper()).post {
//                    searchSuggestionsLinearLayout!!.addView(
//                        v
//                    )
//                }
//                textView.setOnClickListener {
//                    searchView!!.setText(s)
//                    initSearch(searchView!!)
//                }
//                val mb = v.findViewById<ImageButton>(R.id.set_search_query_button)
//                mb.setOnClickListener {
//                    searchView!!.editText.setText(s)
//                    searchView!!.editText.setSelection(searchView!!.editText.length())
//                }
//            }
//            searchSuggestionsLinearLayout!!.isVisible = suggestions.isNotEmpty()

            if (Patterns.WEB_URL.matcher(searchView!!.editText.text).matches()){
                providersChipGroup?.visibility = GONE
                chipGroupDivider?.visibility = GONE
            }else{
                providersChipGroup?.visibility = VISIBLE
                chipGroupDivider?.visibility = VISIBLE
            }
        }

    }

    private fun initSearch(searchView: SearchView){

        queryList = mutableListOf()
        if (queriesChipGroup!!.childCount > 0){
            queriesChipGroup!!.children.forEach {
                val query = (it as Chip).text.toString().trim {it2 -> it2 <= ' '}
                if (query.isNotEmpty()){
                    queryList.add(query)
                }
            }
            queriesChipGroup!!.removeAllViews()
        }
        if (searchView.editText.text.isNotBlank()) {
            queryList.add(searchView.editText.text.toString())
        }

        if (queryList.isEmpty()) return
        if (queryList.size == 1){
            searchBar!!.setText(searchView.text)
        }

        searchView.hide()
        if(!sharedPreferences!!.getBoolean("incognito", false)){
            queryList.forEach { q ->
                resultViewModel.addSearchQueryToHistory(q)
            }
        }
        startSearch()
    }

    private fun startSearch() {
        lifecycleScope.launch(Dispatchers.IO){
            resultViewModel.deleteAll()
            if(sharedPreferences!!.getBoolean("quick_download", false) || sharedPreferences!!.getString("preferred_download_type", "video") == "command"){
                if (queryList.size == 1 && Patterns.WEB_URL.matcher(queryList.first()).matches()){
                    if (sharedPreferences!!.getBoolean("download_card", true)) {
                        withContext(Dispatchers.Main){
                            showSingleDownloadSheet(
                                resultItem = downloadViewModel.createEmptyResultItem(queryList.first()),
                                type = DownloadType.valueOf(sharedPreferences!!.getString("preferred_download_type", "video")!!)
                            )
                        }
                    } else {
                        val downloadItem = downloadViewModel.createDownloadItemFromResult(
                            result = downloadViewModel.createEmptyResultItem(queryList.first()),
                            givenType = DownloadType.valueOf(sharedPreferences!!.getString("preferred_download_type", "video")!!)
                        )
                        downloadViewModel.queueDownloads(listOf(downloadItem))
                    }

                }else{
                    resultViewModel.parseQueries(queryList){}
                }
            }else{
                resultViewModel.parseQueries(queryList){}
            }
        }
    }

    fun scrollToTop() {
        recyclerView!!.scrollToPosition(0)
        runCatching { (searchBar!!.parent as AppBarLayout).setExpanded(true, true) }
    }

    @SuppressLint("ResourceType")
    override fun onButtonClick(item: ResultItem, type: DownloadType?) {
        if (sharedPreferences!!.getBoolean("download_card", true)) {
            showSingleDownloadSheet(item, type!!)
        } else {
            lifecycleScope.launch{
                val downloadItem = withContext(Dispatchers.IO){
                    downloadViewModel.createDownloadItemFromResult(
                        result = item,
                        givenType = type!!)
                }
                downloadViewModel.queueDownloads(listOf(downloadItem))
            }
        }
    }

    override fun onLongButtonClick(item: ResultItem, type: DownloadType?) {
        showSingleDownloadSheet(item, type!!)
    }

    @OptIn(ExperimentalBadgeUtils::class)
    private fun initToolbarMenu() {
        val toolbar = materialToolbar ?: return
        toolbar.inflateMenu(R.menu.home_toolbar_menu)
        val failedItem = toolbar.menu.findItem(R.id.failed_fetches)
        val updatesItem = toolbar.menu.findItem(R.id.app_updates)
        // the button is a custom action view, so it doesn't reach the menu item listener
        updatesItem.actionView?.findViewById<View>(R.id.update_button)?.setOnClickListener { showAvailableUpdates() }
        toolbar.setOnMenuItemClickListener { m ->
            when (m.itemId) {
                R.id.failed_fetches -> {
                    showFailedFetches()
                    true
                }
                R.id.app_updates -> {
                    showAvailableUpdates()
                    true
                }
                else -> false
            }
        }

        val badge = BadgeDrawable.create(requireContext())
        var badgeAttached = false

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    resultViewModel.availableUpdates.collect { updatesItem.isVisible = it.isNotEmpty() }
                }
                launch {
                    resultViewModel.failedQueries.collect { list ->
                        failedItem.isVisible = list.isNotEmpty()
                        badge.number = list.size
                        badge.badgeTextColor = requireContext().getColor(R.color.black)
                        badge.backgroundColor = requireContext().getColor(R.color.white)

                        if (list.isNotEmpty() && !badgeAttached) {
                            // the action view only exists after the toolbar lays out the now visible item
                            toolbar.post {
                                if (failedItem.isVisible && !badgeAttached) {
                                    BadgeUtils.attachBadgeDrawable(badge, toolbar, R.id.failed_fetches)
                                    badgeAttached = true
                                }
                            }
                        } else if (list.isEmpty() && badgeAttached) {
                            BadgeUtils.detachBadgeDrawable(badge, toolbar, R.id.failed_fetches)
                            badgeAttached = false
                        }
                    }
                }
                launch {
                    resultViewModel.failedQueriesEvent.collect { count ->
                        Snackbar.make(requireView(), resources.getQuantityString(R.plurals.items_failed_to_fetch, count, count), Snackbar.LENGTH_LONG)
                            .setAction(R.string.view) { showFailedFetches() }
                            .show()
                    }
                }
            }
        }
    }

    private fun showAvailableUpdates() {
        if (childFragmentManager.findFragmentByTag("updates") != null) return
        UpdatesDialog().show(childFragmentManager, "updates")
    }

    override fun onUpdateSelected(update: ResultViewModel.AvailableUpdate) {
        val activity = requireActivity() as MainActivity
        when (update) {
            is ResultViewModel.AvailableUpdate.App -> UiUtil.showNewAppUpdateDialog(
                update.release, activity, update.updateUtil, activity,
                PreferenceManager.getDefaultSharedPreferences(activity), activity.installLauncher
            )
            is ResultViewModel.AvailableUpdate.Package -> UiUtil.showNewReleaseUpdateDialog(
                update.release, update.item, activity, activity,
                activity.findViewById(R.id.frame_layout),
                activity.findViewById(R.id.bottomNavigationView),
                activity.installLauncher
            ) { result ->
                result.onSuccess {
                    resultViewModel.dismissUpdate(update)
                    RuntimeManager.reInit(activity)
                }.onFailure { f ->
                    Snackbar.make(activity.findViewById(R.id.frame_layout), f.message ?: "", Snackbar.LENGTH_LONG).apply {
                        anchorView = activity.findViewById(R.id.bottomNavigationView)
                        show()
                    }
                }
            }
        }
    }

    private fun showFailedFetches() {
        if (childFragmentManager.findFragmentByTag("failedFetches") != null) return
        FailedFetchesBottomSheetDialog().show(childFragmentManager, "failedFetches")
    }

    override fun onDownloadAnyway(url: String) {
        lifecycleScope.launch {
            val type = DownloadType.valueOf(sharedPreferences!!.getString("preferred_download_type", "video")!!)
            if (sharedPreferences!!.getBoolean("download_card", true)) {
                withContext(Dispatchers.Main){
                    showSingleDownloadSheet(
                        resultItem = downloadViewModel.createEmptyResultItem(url),
                        type = type,
                        disableUpdateData = true
                    )
                }
            } else {
                val downloadItem = downloadViewModel.createDownloadItemFromResult(
                    result = downloadViewModel.createEmptyResultItem(url),
                    givenType = type
                )
                downloadViewModel.queueDownloads(listOf(downloadItem))
            }
        }
    }

    @SuppressLint("RestrictedApi")
    private fun showSingleDownloadSheet(
        resultItem: ResultItem,
        type: DownloadType,
        disableUpdateData : Boolean = false
    ){
        if(findNavController().currentBackStack.value.firstOrNull {it.destination.id == R.id.downloadBottomSheetDialog} == null &&
            findNavController().currentDestination?.id == R.id.homeFragment
            ){
            //show the fragment if its not in the backstack
            val bundle = Bundle()
            downloadCardViewModel.setResultItem(resultItem)
            downloadCardViewModel.setDownloadItem(null)
            bundle.putSerializable("type", downloadViewModel.getDownloadType(type, resultItem.url))
            if (disableUpdateData) {
                bundle.putBoolean("disableUpdateData", true)
            }
            findNavController().navigate(R.id.downloadBottomSheetDialog, bundle)
        }
    }

    override fun onCardClick(item: ResultItem, add: Boolean) {
        lifecycleScope.launch {
            val selectedObjects = homeAdapter.getSelectedObjectsCount(totalCount)
            if (actionMode == null) actionMode = (getActivity() as AppCompatActivity?)!!.startSupportActionMode(contextualActionBar)
            actionMode?.apply {
                if (selectedObjects == 0){
                    this.finish()
                }else{
                    actionMode?.title = "$selectedObjects ${getString(R.string.selected)}"
                    this.menu.findItem(R.id.select_between).isVisible = false
                    if(selectedObjects == 2){
                        val selectedIDs = contextualActionBar.getSelectedIDs().sortedBy { it }
                        val resultsInMiddle = withContext(Dispatchers.IO){
                            resultViewModel.getResultsBetweenTwoItems(selectedIDs.first(), selectedIDs.last())
                        }.toMutableList()
                        this.menu.findItem(R.id.select_between).isVisible = resultsInMiddle.isNotEmpty()
                    }
                }
            }
        }
    }

    override fun onCardDetailsClick(item: ResultItem) {
        if (parentFragmentManager.findFragmentByTag("resultDetails") == null){
            val bundle = Bundle()
            bundle.putParcelable("result", item)
            findNavController().navigate(R.id.resultCardDetailsDialog, bundle)
        }
    }

    override fun onClick(v: View) {
        val viewIdName: String = try {
            v.tag.toString()
        } catch (e: Exception) {""}
        if (viewIdName.isNotEmpty()) {
            if (viewIdName == "downloadAll") {
                val showDownloadCard = sharedPreferences!!.getBoolean("download_card", true)

                lifecycleScope.launch {
                    val resultIds = withContext(Dispatchers.IO) {
                        resultViewModel.getAllIds()
                    }

                    downloadViewModel.turnResultItemsToProcessingDownloads(resultIds, downloadNow = !showDownloadCard)
                    if (showDownloadCard){
                        findNavController().navigate(R.id.downloadMultipleBottomSheetDialog2)
                    }
                }


            }
        }
    }

    // YTindir: the copied link is shown as a card above the navigation instead of a floating button
    private fun setClipboardVisible(visible: Boolean) {
        clipboardFab?.isVisible = false
        clipboardCard?.isVisible = visible
    }

    private fun bindClipboardCard(links: List<String>) {
        val card = clipboardCard ?: return
        card.findViewById<TextView>(R.id.clipboard_url).text =
            if (links.size == 1) links.first() else links.joinToString("  ·  ")
        val thumb = card.findViewById<ImageView>(R.id.clipboard_thumb)
        val videoId = links.firstOrNull()?.let {
            Regex("""(?:v=|youtu\.be/|shorts/|live/|embed/)([A-Za-z0-9_-]{11})""").find(it)?.groupValues?.get(1)
        }
        if (videoId != null && links.size == 1) {
            ImageViewCompat.setImageTintList(thumb, null)
            thumb.setPadding(0, 0, 0, 0)
            Picasso.get().load("https://i.ytimg.com/vi/$videoId/mqdefault.jpg").into(thumb)
        }
        val open = View.OnClickListener { clipboardFab?.performClick() }
        card.setOnClickListener(open)
        card.findViewById<View>(R.id.clipboard_download).setOnClickListener(open)
        card.findViewById<View>(R.id.clipboard_dismiss).setOnClickListener {
            showClipboardFab = false
            setClipboardVisible(false)
        }
    }

    private val contextualActionBar = object : ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean {
            mode!!.menuInflater.inflate(R.menu.main_menu_context, menu)
            mode.title = "${homeAdapter.getSelectedObjectsCount(totalCount)} ${getString(R.string.selected)}"
            searchBar!!.isEnabled = false
            playlistNameFilterChipGroup.children.forEach { it.isEnabled = false }
            searchBar!!.menu.forEach { it.isEnabled = false }
            (activity as MainActivity).disableBottomNavigation()
            downloadAllFab!!.isVisible = false
            setClipboardVisible(false)
            return true
        }

        override fun onPrepareActionMode(
            mode: ActionMode?,
            menu: Menu?
        ): Boolean {
            return false
        }

        override fun onActionItemClicked(
            mode: ActionMode?,
            item: MenuItem?
        ): Boolean {
            return when (item!!.itemId) {
                R.id.select_between -> {
                    lifecycleScope.launch {
                        val selectedIDs = getSelectedIDs().toMutableList()
                        val resultsInMiddle = withContext(Dispatchers.IO){
                            resultViewModel.getResultsBetweenTwoItems(selectedIDs.first(), selectedIDs.last())
                        }.toMutableList()
                        if (resultsInMiddle.isNotEmpty()){
                            selectedIDs.addAll(resultsInMiddle.map { it.id })
                            homeAdapter.checkMultipleItems(selectedIDs)
                            actionMode?.title = "${selectedIDs.count()} ${getString(R.string.selected)}"
                        }
                        mode?.menu?.findItem(R.id.select_between)?.isVisible = false
                    }
                    true
                }
                R.id.delete_results -> {
                    val deleteDialog = MaterialAlertDialogBuilder(fragmentContext!!)
                    deleteDialog.setTitle(getString(R.string.you_are_going_to_delete_multiple_items))
                    deleteDialog.setNegativeButton(getString(R.string.cancel)) { dialogInterface: DialogInterface, _: Int -> dialogInterface.cancel() }
                    deleteDialog.setPositiveButton(getString(R.string.ok)) { _: DialogInterface?, _: Int ->
                        lifecycleScope.launch {
                            val selectedObjects = getSelectedIDs()
                            if (selectedObjects.size == totalCount) {
                                resultViewModel.deleteAll()
                            } else {
                                resultViewModel.deleteSelected(selectedObjects)
                            }
                            homeAdapter.clearCheckedItems()
                            actionMode?.finish()
                        }
                    }
                    deleteDialog.show()
                    true
                }
                R.id.download -> {
                    lifecycleScope.launch {
                        val showDownloadCard = sharedPreferences!!.getBoolean("download_card", true)
                        val selectedObjects = getSelectedIDs()

                        if (showDownloadCard && selectedObjects.size == 1) {
                            var resultItem = withContext(Dispatchers.IO) {
                                resultViewModel.getByID(selectedObjects.first())
                            }

                            resultItem?.apply {
                                showSingleDownloadSheet(
                                    resultItem,
                                    downloadViewModel.getDownloadType(url = resultItem.url)
                                )
                            }
                        }else{
                            downloadViewModel.turnResultItemsToProcessingDownloads(selectedObjects, downloadNow = !showDownloadCard)
                            if (showDownloadCard){
                                findNavController().navigate(R.id.downloadMultipleBottomSheetDialog2)
                            }
                        }
                        homeAdapter.clearCheckedItems()
                        actionMode?.finish()
                    }
                    true
                }
                R.id.select_all -> {
                    homeAdapter.checkAll()
                    val selectedCount = homeAdapter.getSelectedObjectsCount(totalCount)
                    mode?.title = "(${selectedCount}) ${resources.getString(R.string.all_items_selected)}"
                    true
                }
                R.id.invert_selected -> {
                    homeAdapter.invertSelected()
                    val selectedCount = homeAdapter.getSelectedObjectsCount(totalCount)
                    actionMode!!.title = "$selectedCount ${getString(R.string.selected)}"
                    if (selectedCount == 0) actionMode?.finish()
                    true
                }
                else -> false
            }
        }

        override fun onDestroyActionMode(mode: ActionMode?) {
            actionMode = null
            (activity as MainActivity).enableBottomNavigation()
            homeAdapter.clearCheckedItems()
            searchBar!!.isEnabled = true
            playlistNameFilterChipGroup.children.forEach { it.isEnabled = true }
            searchBar!!.menu.forEach { it.isEnabled = true }
            searchBar?.expand(appBarLayout!!)

            downloadAllFab!!.isVisible = showDownloadAllFab
            setClipboardVisible(showClipboardFab)
        }

        suspend fun getSelectedIDs() : List<Long>{
            return if (homeAdapter.inverted || homeAdapter.checkedItems.isEmpty()){
                withContext(Dispatchers.IO){
                    resultViewModel.getItemIDsNotPresentIn(homeAdapter.checkedItems.toList())
                }
            }else{
                homeAdapter.checkedItems.toList()
            }
        }
    }

    private fun checkClipboard(): List<String>?{
        val checkClipboard = sharedPreferences!!.getBoolean("check_clipboard_home", true)
        if (!checkClipboard) return null

        return runCatching {
            val clipboard = requireContext().getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val clip = clipboard.primaryClip!!.getItemAt(0).text
            return clip.split("\r","\n").map { it.trim() }.filter { Patterns.WEB_URL.matcher(it).matches() }
        }.getOrNull()
    }


    companion object {
        private const val TAG = "HomeFragment"
    }

    override fun onSearchSuggestionClick(text: String) {
        val res = text.split("\n")
        if (res.size == 1){
            showClipboardFab = false
            setClipboardVisible(false)
            searchView!!.setText(text)
            initSearch(searchView!!)
        }else{
            res.forEach {
                onSearchSuggestionAdd(it)
            }
        }

    }

    override fun onSearchSuggestionAdd(text: String) {
        val items = text.split("\n")

        items.forEach {t ->
            val present = queriesChipGroup!!.children.firstOrNull { (it as Chip).text.toString() == t }
            if (present == null) {
                val chip = layoutinflater!!.inflate(R.layout.input_chip, queriesChipGroup, false) as Chip
                chip.text = t
                chip.chipBackgroundColor = ColorStateList.valueOf(MaterialColors.getColor(requireContext(), R.attr.colorSecondaryContainer, Color.BLACK))
                chip.setOnClickListener {
                    if (queriesChipGroup!!.childCount == 1) queriesConstraint!!.visibility = GONE
                    queriesChipGroup!!.removeView(chip)
                }
                queriesChipGroup!!.addView(chip)
            }

        }

        searchView!!.editText.setText("")
        queriesConstraint?.isVisible = queriesChipGroup?.childCount!! > 0

        searchSuggestionsAdapter?.getList()?.apply {
            if (this.isNotEmpty()) {
                if (this.first().type == SearchSuggestionType.CLIPBOARD){
                    val newList = this.toMutableList().drop(1)
                    searchSuggestionsAdapter?.submitList(newList)
                }
            }

        }
    }

    override fun onSearchSuggestionLongClick(text: String, position: Int) {
        val deleteDialog = MaterialAlertDialogBuilder(requireContext())
        deleteDialog.setTitle(getString(R.string.you_are_going_to_delete) + " \"" + text + "\"!")
        deleteDialog.setNegativeButton(getString(R.string.cancel)) { dialogInterface: DialogInterface, _: Int -> dialogInterface.cancel() }
        deleteDialog.setPositiveButton(getString(R.string.ok)) { _: DialogInterface?, _: Int ->
            resultViewModel.removeSearchQueryFromHistory(text)
            updateSearchViewItems(searchView!!.editText.text.toString())
        }
        deleteDialog.show()
    }

    override fun onSearchSuggestionAddToSearchBar(text: String) {
          searchView!!.editText.setText(text)
          searchView!!.editText.setSelection(searchView!!.editText.length())
    }


    private fun updateMultiplePlaylistResults(playlistTitles: List<String>) {
        playlistNameFilterChipGroup.children.filter { it.tag != "all" }.forEach {
            playlistNameFilterChipGroup.removeView(it)
        }

        if (playlistTitles.isEmpty() || playlistTitles.size == 1) {
            playlistNameFilterScrollView.isVisible = false
            return
        }

        playlistNameFilterChipGroup.children.first().setOnClickListener {
            resultViewModel.setPlaylistFilter("")
        }

        for (t in playlistTitles) {
            val tmp = layoutinflater!!.inflate(R.layout.filter_chip, playlistNameFilterChipGroup, false) as Chip
            tmp.text = t
            tmp.tag = t
            tmp.setOnClickListener {
                resultViewModel.setPlaylistFilter(t)
            }

            playlistNameFilterChipGroup.addView(tmp)
        }

        if (playlistNameFilterChipGroup.children.all { !(it as Chip).isChecked }) {
            (playlistNameFilterChipGroup.children.first() as Chip).isChecked = true
        }

        playlistNameFilterScrollView.isVisible = true
    }
}