package com.deniscerri.ytdl.util.extractors.ytdlp

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import androidx.preference.PreferenceManager
import com.afollestad.materialdialogs.utils.MDUtil.getStringArray
import com.anggrayudi.storage.extension.count
import com.deniscerri.ytdl.R
import com.deniscerri.ytdl.core.RuntimeManager
import com.deniscerri.ytdl.core.models.YTDLRequest
import com.deniscerri.ytdl.database.dao.CommandTemplateDao
import com.deniscerri.ytdl.database.enums.DownloadType
import com.deniscerri.ytdl.database.models.ChapterItem
import com.deniscerri.ytdl.database.models.DownloadItem
import com.deniscerri.ytdl.database.models.Format
import com.deniscerri.ytdl.database.models.ResultItem
import com.deniscerri.ytdl.database.models.YoutubeGeneratePoTokenItem
import com.deniscerri.ytdl.database.models.YoutubePlayerClientItem
import com.deniscerri.ytdl.database.viewmodel.ResultViewModel
import com.deniscerri.ytdl.util.BgUtilsPoTokenGeneratorUtil
import com.deniscerri.ytdl.util.Extensions.getIDFromYoutubeURL
import com.deniscerri.ytdl.util.Extensions.getIntByAny
import com.deniscerri.ytdl.util.Extensions.getStringByAny
import com.deniscerri.ytdl.util.Extensions.isSoundCloudURL
import com.deniscerri.ytdl.util.Extensions.isURL
import com.deniscerri.ytdl.util.Extensions.isYoutubeURL
import com.deniscerri.ytdl.util.Extensions.isYoutubeWatchVideosURL
import com.deniscerri.ytdl.util.Extensions.readJsonValue
import com.deniscerri.ytdl.util.Extensions.toStringDuration
import com.deniscerri.ytdl.util.FileNameCleaner
import com.deniscerri.ytdl.util.FileUtil
import com.deniscerri.ytdl.util.FormatUtil
import com.deniscerri.ytdl.util.SocialMediaUtil
import com.google.gson.Gson
import com.google.gson.Strictness
import com.google.gson.reflect.TypeToken
import com.google.gson.stream.JsonReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.job
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.io.InputStreamReader
import java.lang.reflect.Type
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.StringJoiner
import java.util.UUID
import java.util.zip.CRC32

class YTDLPUtil(private val context: Context, private val commandTemplateDao: CommandTemplateDao) {
    private var sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
    private val formatUtil = FormatUtil(context)
    private val handler = Handler(Looper.getMainLooper())

    private fun YTDLRequest.applyDefaultOptionsForFetchingData(url: String?) {
        addOption("--skip-download")
        addOption("--quiet")
        addOption("--ignore-errors")
        addOption("--no-warnings")
        addOption("-R", "1")

        val compatOptions = mutableListOf("manifest-filesize-approx")
        if (url?.isYoutubeURL() == true) {
            compatOptions.add("no-youtube-unavailable-videos")
        }
        addOption("--compat-options", compatOptions.joinToString(","))

        val socketTimeout = sharedPreferences.getString("socket_timeout", "5")!!.ifEmpty { "5" }
        addOption("--socket-timeout", socketTimeout)

        if (sharedPreferences.getBoolean("force_ipv4", false)){
            addOption("-4")
        }

        if (useCookiesFor(url)){
            FileUtil.getCookieFile(context){
                addOption("--cookies", it)
            }

            val useHeader = sharedPreferences.getBoolean("use_header", false)
            val header = sharedPreferences.getString("useragent_header", "")
            if (useHeader && !header.isNullOrBlank()){
                addOption("--add-header","User-Agent:${header}")
            }
        }

        val proxy = sharedPreferences.getString("proxy", "")
        if (proxy!!.isNotBlank()){
            addOption("--proxy", proxy)
        }
        addOption("-P", FileUtil.getCachePath(context) + "/tmp")
        // YTindir: our extractor plugins (Instagram stories) also read the post, not only download it
        addOption("--plugin-dirs", FileUtil.getBundledYTDLPPluginsPath(context))

        if (sharedPreferences.getBoolean("no_check_certificates", false)) {
            addOption("--no-check-certificates")
        }

        var extraCommands = commandTemplateDao.getAllTemplatesAsDataFetchingExtraCommands()

        extraCommands = if (url != null) {
            extraCommands.filter {
                it.urlRegex.any { u -> Regex(u).containsMatchIn(url) } ||
                it.urlRegex.isEmpty()
            }
        }else{
            extraCommands.filter { it.urlRegex.isEmpty() }
        }

        if (extraCommands.isNotEmpty()){
            //addCommands(extraCommands.split(" ", "\t", "\n"))
            addConfig(extraCommands.joinToString(" ") { it.content })
        }
    }

    /**
     * YTindir: Instagram's website gives a lower bitrate HE-AAC audio; its app API (as the app reads
     * posts, which needs a logged-in account in the cookies) has the higher quality xHE-AAC, but its
     * best video streams are AV1, HEVC or HDR VP9. So the video stays the website's and only the app's
     * audio is downloaded on its own after it (then converted to AAC-LC, see XheAacConverter).
     */
    fun canUseInstagramAppAudio(url: String): Boolean {
        if (SocialMediaUtil.siteOf(url) != SocialMediaUtil.Site.INSTAGRAM) return false
        if (!useCookiesFor(url)) return false
        if (!sharedPreferences.getBoolean("instagram_app_api", true)) return false
        var session = false
        FileUtil.getCookieFile(context) { session = SocialMediaUtil.hasInstagramSession(File(it)) }
        return session
    }

    /** Downloads the post's audio through Instagram's app API into [dir]; null when it fails. */
    suspend fun downloadInstagramAppAudio(url: String, dir: File, processId: String): File? {
        dir.deleteRecursively()
        dir.mkdirs()
        val request = YTDLRequest(url)
        FileUtil.getCookieFile(context) { request.addOption("--cookies", it) }
        // our Instagram story plugin too (stories get the app's audio the same way)
        request.addOption("--plugin-dirs", FileUtil.getBundledYTDLPPluginsPath(context))
        request.addOption("--extractor-args", INSTAGRAM_APP_API_ARGS)
        // the app API answers anything but its own app with "HTTP Error 400"
        request.addOption("--add-headers", "User-Agent:$INSTAGRAM_IOS_USER_AGENT")
        request.addOption("--no-playlist")
        request.addOption("--no-mtime")
        request.addOption("-f", "ba[vcodec=none]/ba")
        request.addOption("-P", dir.absolutePath)
        request.addOption("-o", "app_audio.%(ext)s")
        val proxy = sharedPreferences.getString("proxy", "")
        if (!proxy.isNullOrBlank()) request.addOption("--proxy", proxy)
        return runCatching {
            RuntimeManager.getInstance().runKillable { id ->
                RuntimeManager.getInstance().execute(request, id)
            }
            dir.listFiles()?.firstOrNull { it.isFile && it.name.startsWith("app_audio.") && !it.name.endsWith(".part") }
        }.getOrNull()
    }

    /**
     * YTindir: whether yt-dlp gets the cookies for [url]: not for Instagram posts while the saved
     * Instagram session is known to be logged out (see SocialMediaUtil.isInstagramSessionStale).
     */
    fun useCookiesFor(url: String?): Boolean {
        if (!sharedPreferences.getBoolean("use_cookies", false)) return false
        if (SocialMediaUtil.siteOf(url) != SocialMediaUtil.Site.INSTAGRAM) return true
        var stale = false
        FileUtil.getCookieFile(context) { stale = SocialMediaUtil.isInstagramSessionStale(sharedPreferences, File(it)) }
        return !stale
    }

    /**
     * YTindir: an Instagram post that failed with the cookies gets one more try as a logged-out
     * visitor; the session is marked stale meanwhile and stays so only when that try works.
     * Returns null when no such try applies (not Instagram, no cookies, or already without them).
     */
    private suspend fun <T> retryInstagramWithoutCookies(url: String?, attempt: suspend () -> T, worked: (T) -> Boolean): T? {
        if (SocialMediaUtil.siteOf(url) != SocialMediaUtil.Site.INSTAGRAM || !useCookiesFor(url)) return null
        var cookieFile: File? = null
        FileUtil.getCookieFile(context) { cookieFile = File(it) }
        val file = cookieFile ?: return null
        if (!SocialMediaUtil.hasInstagramSession(file)) return null
        // still logged in: the failure is something else, the cookies stay
        val session = withContext(Dispatchers.IO) { SocialMediaUtil.checkInstagramSession(file) }
        if (session == true) return null
        SocialMediaUtil.setInstagramSessionStale(sharedPreferences, file, true)
        val result = runCatching { attempt() }
        val ok = result.getOrNull()?.let(worked) == true
        // kept only when Instagram said the login is gone and the post works without it; when
        // Instagram couldn't be asked, this one post was read without the cookies and that's all
        if (!ok || session == null) SocialMediaUtil.setInstagramSessionStale(sharedPreferences, file, false)
        return result.getOrThrow()
    }

    private fun canApplyFlatPlaylist(url: String) : Boolean {
        var noFlatPlaylist = sharedPreferences.getBoolean("no_flat_playlist", false)
        if (url.isSoundCloudURL()) {
            noFlatPlaylist = true
        }

        return !noFlatPlaylist
    }

    @SuppressLint("RestrictedApi")
    suspend fun getFromYTDL(query: String, singleItem: Boolean = false, resultsGenerated: suspend (pagedResults: List<ResultItem>) -> Unit): List<ResultItem> {
        val searchEngine = sharedPreferences.getString("search_engine", "ytsearch")

        val request : YTDLRequest
        if (query.contains("http")){
            if (query.isYoutubeWatchVideosURL()) {
                request = YTDLRequest(emptyList())
                val config =
                    File(context.cacheDir.absolutePath + "/config" + System.currentTimeMillis() + "##url.txt")
                config.writeText(query)
                request.addOption("--config", config.absolutePath)
            }else{
                request = YTDLRequest(query)
            }
            request.addWriteInfoJson(query)
        }else{
            request = YTDLRequest(emptyList())
            when (searchEngine){
                "ytsearchmusic" -> {
                    request.addOption("--default-search", "https://music.youtube.com/search?q=")
                    request.addOption("ytsearch25:\"${query}\"")
                }
                else -> {
                    request.addOption("${searchEngine}25:\"${query}\"")
                }
            }
        }
        if (searchEngine == "ytsearch" || query.isYoutubeURL()) {
            request.setYoutubeExtractorArgs(query)
        }

        if (canApplyFlatPlaylist(query)) {
            request.addOption("--flat-playlist")
        }

        request.addOption("--lazy-playlist")
        request.addOption(if (singleItem) "-J" else "-j")
        request.applyDefaultOptionsForFetchingData(if (query.isURL()) query else null)
        val usePlaylistOriginalURL = sharedPreferences.getBoolean("use_original_url_playlist", false)

        val finalResults = mutableListOf<ResultItem>()
        var postedProgress = false
        // callbacks run on the stdout reader thread inside runBlocking, which doesn't see the caller being cancelled
        val callerJob = currentCoroutineContext().job
        try {
        RuntimeManager.getInstance().runKillable { processId ->
        RuntimeManager.getInstance().execute(request, processId) { progress, _, line ->
            if (!callerJob.isActive) return@execute
            runCatching {
                val generatedResults = parseYTDLPListResults(listOf(line))
                if (generatedResults.isNotEmpty()) {

                    generatedResults.forEach {
                        if (!it.playlistURL.isNullOrBlank() && usePlaylistOriginalURL && query.contains("http")) {
                            it.playlistURL = query
                        }
                    }

                    finalResults.addAll(generatedResults)
                    if (!postedProgress) {
                        if (finalResults.size > 1) {
                            runBlocking {
                                resultsGenerated(finalResults)
                            }
                            postedProgress = true
                        }
                    }else{
                        runBlocking {
                            resultsGenerated(generatedResults)
                        }
                    }
                }
            }
        }
        }
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            // YTindir: a logged-out Instagram session in the cookies: read the post as a visitor
            if (finalResults.isEmpty()) {
                retryInstagramWithoutCookies(query, { getFromYTDL(query, singleItem, resultsGenerated) }, { it.isNotEmpty() })
                    ?.let { return it }
            }
            // YTindir: TikTok sometimes answers yt-dlp with "HTTP Error 403"; tikwm.com still knows
            // the post, and its original is what gets downloaded anyway
            val fallback = if (finalResults.isEmpty() && SocialMediaUtil.siteOf(query) == SocialMediaUtil.Site.TIKTOK) {
                withContext(Dispatchers.IO) { tikTokResultFromTikwm(query) }
            } else null
            if (fallback == null) throw e
            resultsGenerated(listOf(fallback))
            return listOf(fallback)
        }

        currentCoroutineContext().ensureActive()
        if (!postedProgress) resultsGenerated(finalResults)
        return finalResults
    }

    private fun tikTokResultFromTikwm(url: String): ResultItem? {
        val info = SocialMediaUtil.getTikTokInfo(url) ?: return null
        val formats = arrayListOf<Format>()
        addSourceFormats(SocialMediaUtil.Site.TIKTOK, formats)
        return ResultItem(
            0,
            url = url,
            title = info.fileTitle.ifBlank { info.caption },
            author = info.handle.ifBlank { info.nickname },
            duration = if (info.durationSeconds > 0) info.durationSeconds.toStringDuration(Locale.US) else "-1",
            thumb = info.cover,
            website = "TikTok",
            playlistTitle = "",
            formats = formats,
            urls = "",
            chapters = arrayListOf(),
        )
    }

    private fun parseYTDLPListResults(results: List<String?>, query: String = "") : ArrayList<ResultItem> {
        val items = arrayListOf<ResultItem>()

        for (result in results) {
            if (result.isNullOrBlank()) continue
            val jsonObject = JSONObject(result)
            var title = jsonObject.getStringByAny("alt_title", "title", "webpage_url_basename")
            if (title == "[Private video]" || title == "[Deleted video]") continue


            var playlistTitle = jsonObject.getStringByAny("playlist_title")
            var playlistURL: String? = ""
            var playlistIndex: Int? = null

            if(playlistTitle.removeSurrounding("\"") == query) playlistTitle = ""

            if (playlistTitle.isNotBlank()){
                playlistURL = jsonObject.getStringByAny("playlist_webpage_url").ifEmpty { query }
                runCatching { playlistIndex = jsonObject.getInt("playlist_index") }
            }
            val url = if (jsonObject.has("url") && results.size > 1){
                jsonObject.getString("url")
            }else{
                if (Patterns.WEB_URL.matcher(query).matches() && playlistURL?.isEmpty() == true){
                    query
                }else{
                    jsonObject.getStringByAny("webpage_url", "original_url", "url")
                }
            }

            val authorTags = mutableListOf("uploader", "channel", "playlist_uploader", "uploader_id")
            if (url.isYoutubeURL()) {
                authorTags.addAll(0, listOf("artists", "artist", "creators"))
            }
            var author = jsonObject.getStringByAny(*authorTags.map { it }.toTypedArray()).removeSuffix(" - Topic")
            var duration = jsonObject.getIntByAny("duration").toString()
            if (duration != "-1"){
                duration = jsonObject.getInt("duration").toStringDuration(Locale.US)
            }

            var thumb: String? = ""
            if (jsonObject.has("thumbnail")) {
                thumb = jsonObject.getString("thumbnail")
            } else if (jsonObject.has("thumbnails")) {
                val thumbs = jsonObject.getJSONArray("thumbnails")
                if (thumbs.length() > 0){
                    thumb = thumbs.getJSONObject(thumbs.length() - 1).getString("url")
                }
            }

            if(author.isEmpty()){
                runCatching {
                    val firstEntry = jsonObject.getJSONArray("entries").getJSONObject(0)
                    author = firstEntry.getStringByAny("uploader", "channel", "playlist_uploader", "uploader_id")
                    val thumbs = firstEntry.getJSONArray("thumbnails")
                    if (thumbs.length() > 0){
                        thumb = thumbs.getJSONObject(thumbs.length() - 1).getString("url")
                    }
                }
            }

            var website = jsonObject.getStringByAny("extractor_key", "extractor","ie_key")
            if (website == "Generic" || website == "HTML5MediaEmbed") website = jsonObject.getStringByAny("webpage_url_domain")


            val formatsInJSON = if (jsonObject.has("formats") && jsonObject.get("formats") is JSONArray) jsonObject.getJSONArray("formats") else null
            val formats : ArrayList<Format> = parseYTDLFormats(formatsInJSON)

            // YTindir: Instagram, X, TikTok and Facebook posts get "username_postid" titles instead of
            // "Video by …" or a whole caption, and TikTok its original (source) quality
            SocialMediaUtil.siteOf(url, website)?.let { site ->
                if (jsonObject.getStringByAny("_type") != "playlist") {
                    SocialMediaUtil.fileTitle(site, jsonObject, url, author)?.let { title = it }
                } else if (playlistTitle.isBlank() || playlistTitle == title) {
                    // a whole carousel: "username_postid" for it too, not its caption or nothing
                    SocialMediaUtil.fileTitle(site, jsonObject, url, author)?.let { title = it }
                }
                addSourceFormats(site, formats)
            }

            val chaptersInJSON = if (jsonObject.has("chapters") && jsonObject.get("chapters") is JSONArray) jsonObject.getJSONArray("chapters") else null
            val listType: Type = object : TypeToken<List<ChapterItem>>() {}.type
            var chapters : ArrayList<ChapterItem> = arrayListOf()

            if (chaptersInJSON != null){
                chapters = Gson().fromJson(chaptersInJSON.toString(), listType)
            }

            var urls = "";
            if(jsonObject.has("requested_formats")) {
                val requestedFormats = jsonObject.getJSONArray("requested_formats")
                val urlList = mutableListOf<String>()
                val length = requestedFormats.length()-1
                for (i in length downTo 0) {
                    urlList.add(requestedFormats.getJSONObject(i).getString("url"))
                }

                urls = urlList.joinToString("\n")
            }



            val type = jsonObject.getStringByAny("_type")
            if (type == "playlist") {
                if (playlistTitle.isEmpty()) {
                    playlistTitle = title
                }
                title = ""
                author = ""
            }


            val availableSubtitles = mutableListOf<String>()
            if (jsonObject.has("subtitles")) {
                runCatching {
                    availableSubtitles.addAll(jsonObject.getJSONObject("subtitles").keys().asSequence().toList())
                }
            }

            val res = ResultItem(
                0,
                url = url,
                title = title,
                author = author,
                duration = duration,
                thumb = thumb!!,
                website = website,
                playlistTitle = playlistTitle,
                formats = formats,
                urls = urls,
                chapters = chapters,
                playlistURL = playlistURL,
                playlistIndex = playlistIndex,
                availableSubtitles = availableSubtitles
            )
            // YTindir: views and upload time for the results list and its sorting
            res.viewCount = jsonObject.optLong("view_count", -1).takeIf { it >= 0 }
            res.uploadDate = jsonObject.optLong("timestamp", -1).takeIf { it > 0 }
                ?: jsonObject.optString("upload_date").takeIf { it.length == 8 }?.let { d ->
                    runCatching {
                        java.time.LocalDate.parse(d, java.time.format.DateTimeFormatter.BASIC_ISO_DATE)
                            .atStartOfDay(java.time.ZoneOffset.UTC).toEpochSecond()
                    }.getOrNull()
                }

            items.add(res)
        }

        return items
    }

    suspend fun getYoutubeWatchLater() : ArrayList<ResultItem> {
        val request = YTDLRequest(listOf())
        request.setYoutubeExtractorArgs(null)
        request.addOption( "-j")
        request.addOption("--flat-playlist")
        request.applyDefaultOptionsForFetchingData(null)
        request.addOption(":ytwatchlater")
        val ytdlResponse = RuntimeManager.getInstance().runKillable { processId ->
            RuntimeManager.getInstance().execute(request, processId)
        }
        val results: List<String?> = try {
            val lineSeparator = System.getProperty("line.separator")
            ytdlResponse.out.split(lineSeparator!!)
        } catch (e: Exception) {
            listOf(ytdlResponse.out)
        }.filter { it.isNotBlank() }.apply {
            if (this.isEmpty()) return arrayListOf()
        }
        return parseYTDLPListResults(results)
    }

    suspend fun getYoutubeRecommendations() : ArrayList<ResultItem> {
        val request = YTDLRequest(listOf())
        request.setYoutubeExtractorArgs(null)
        request.addOption( "-j")
        request.addOption("--flat-playlist")
        request.applyDefaultOptionsForFetchingData(null)
        request.addOption(":ytrec")
        val ytdlResponse = RuntimeManager.getInstance().runKillable { processId ->
            RuntimeManager.getInstance().execute(request, processId)
        }
        val results: List<String?> = try {
            val lineSeparator = System.getProperty("line.separator")
            ytdlResponse.out.split(lineSeparator!!)
        } catch (e: Exception) {
            listOf(ytdlResponse.out)
        }.filter { it.isNotBlank() }.apply {
            if (this.isEmpty()) return arrayListOf()
        }
        return parseYTDLPListResults(results)
    }

    suspend fun getYoutubeLikedVideos() : ArrayList<ResultItem> {
        val request = YTDLRequest(listOf())
        request.setYoutubeExtractorArgs(null)
        request.addOption( "-j")
        request.addOption("--flat-playlist")
        request.applyDefaultOptionsForFetchingData(null)
        request.addOption(":ytfav")
        val ytdlResponse = RuntimeManager.getInstance().runKillable { processId ->
            RuntimeManager.getInstance().execute(request, processId)
        }
        val results: List<String?> = try {
            val lineSeparator = System.getProperty("line.separator")
            ytdlResponse.out.split(lineSeparator!!)
        } catch (e: Exception) {
            listOf(ytdlResponse.out)
        }.filter { it.isNotBlank() }.apply {
            if (this.isEmpty()) return arrayListOf()
        }
        return parseYTDLPListResults(results)
    }

    suspend fun getYoutubeWatchHistory() : ArrayList<ResultItem> {
        val request = YTDLRequest(listOf())
        request.setYoutubeExtractorArgs(null)
        request.addOption( "-j")
        request.addOption("--flat-playlist")
        request.applyDefaultOptionsForFetchingData(null)
        request.addOption(":ythis")
        val ytdlResponse = RuntimeManager.getInstance().runKillable { processId ->
            RuntimeManager.getInstance().execute(request, processId)
        }
        val results: List<String?> = try {
            val lineSeparator = System.getProperty("line.separator")
            ytdlResponse.out.split(lineSeparator!!)
        } catch (e: Exception) {
            listOf(ytdlResponse.out)
        }.filter { it.isNotBlank() }.apply {
            if (this.isEmpty()) return arrayListOf()
        }
        return parseYTDLPListResults(results)
    }


    suspend fun getFormatsForAll(urls: List<String>, progress: (progress: ResultViewModel.MultipleFormatProgress) -> Unit) : Result<MutableList<MutableList<Format>>>  {
        val formatCollection = mutableListOf<MutableList<Format>>()

        val urlsFile = File(context.cacheDir, "urls.txt")
        urlsFile.delete()
        withContext(Dispatchers.IO) {
            urlsFile.createNewFile()
        }
        urls.forEach {
            urlsFile.appendText(it+"\n")
        }

        try {
            val request = YTDLRequest(emptyList())
            request.addOption("--print", "formats")
            request.addOption("-a", urlsFile.absolutePath)
            request.applyDefaultOptionsForFetchingData(urls.firstOrNull { it.isURL() })
            if (urls.all { it.isYoutubeURL() }) {
                request.setYoutubeExtractorArgs(urls[0])
            }
            if (!request.hasOption("--no-check-certificates")) request.addOption("--no-check-certificates")

            val txt = parseYTDLRequestString(request)
            println(txt)

            var urlIdx = 0
            val callerJob = currentCoroutineContext().job
            RuntimeManager.getInstance().runKillable { processId ->
            RuntimeManager.getInstance().execute(request, processId){ progress, _, line ->
                if (!callerJob.isActive) return@execute
                try{
                    if (line.isNotBlank()){
                        val url = urls[urlIdx]
                        println(line)
                        println(url)

                        if (line.contains("unavailable")) {
                            progress(ResultViewModel.MultipleFormatProgress(url, listOf(), true, line))
                        }else{
                            val formatsJSON = JSONArray(line)
                            val formats = parseYTDLFormats(formatsJSON)

                            formatCollection.add(formats)
                            progress(ResultViewModel.MultipleFormatProgress(url, formats))
                        }
                    }

                }catch (e: Exception){
                    Log.e("GET MULTIPLE FORMATS", e.toString())
                }
                urlIdx++
            }
            }
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            e.message?.split(System.lineSeparator())?.onEach { line ->
                println(line)
                if (line.contains("unavailable")) {
                    runCatching {
                        val id = Regex("""\[.*?\] (\w+):""").find(line)!!.groupValues[1]
                        val url = urls.first { it.contains(id) }
                        progress(
                            ResultViewModel.MultipleFormatProgress(
                                url,
                                listOf(),
                                true,
                                line
                            )
                        )
                        delay(500)
                    }
                }

            }

            e.message?.apply {
                handler.post {
                    Toast.makeText(context, e.message, Toast.LENGTH_LONG).show()
                }
            }

            e.printStackTrace()
            return Result.failure(e)
        } finally {
            urlsFile.delete()
        }

        return Result.success(formatCollection)
    }

    suspend fun getFormats(url: String, ignoreInfoJSON: Boolean) : List<Format> {
        val request = YTDLRequest(url)
        request.addOption("--print", "%(formats)j")
        request.addOption("--print", "%(duration)s")
        request.applyDefaultOptionsForFetchingData(url)
        if (url.isYoutubeURL()) {
            request.setYoutubeExtractorArgs(url)
        }
        if (!request.hasOption("--no-check-certificates")) request.addOption("--no-check-certificates")

        val canUseWriteInfoJson =
            !ignoreInfoJSON &&
            !sharedPreferences.getBoolean("disable_write_info_json", false) &&
            !request.toString().contains("--download-sections")

        if (canUseWriteInfoJson) {
            val infoJsonFile = getInfoJsonFile(url)
            //ignore info file if its older than 5 hours. puny measure to prevent expired formats in some cases
            if (infoJsonFile != null && System.currentTimeMillis() - infoJsonFile.lastModified() <= (1000 * 60 * 60 * 5)) {
                request.addOption("--load-info-json", infoJsonFile.absolutePath)
            }else {
                request.addWriteInfoJson(url)
            }
        }

        val formats = try {
            RuntimeManager.getInstance().runKillable { processId ->
                RuntimeManager.getInstance().executeStreaming(request, processId) { stream ->
                    JsonReader(InputStreamReader(stream, StandardCharsets.UTF_8)).use { reader ->
                        reader.strictness = Strictness.LENIENT
                        readFormatsList(reader)
                    }
                }
            }
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            arrayListOf()
        }


        if (formats.isEmpty()) {
            runCatching {
                getInfoJsonFile(url)?.apply { this.delete() }
            }
            // YTindir: a logged-out Instagram session in the cookies: read the post as a visitor
            runCatching {
                retryInstagramWithoutCookies(url, { getFormats(url, true) }, { it.isNotEmpty() })
            }.onFailure { if (it is CancellationException) throw it }.getOrNull()?.let { return it }
        }

        SocialMediaUtil.siteOf(url)?.let { addSourceFormats(it, formats) }

        return formats
    }

    // YTindir: TikTok's own formats are recompressed; the original upload comes from tikwm.com
    // when the download starts (see DownloadWorker), with TikTok's best format as the fallback
    // X: its http files fail to download and report much larger sizes than they are, so only its
    // hls streams are offered (when it has any)
    private fun addSourceFormats(site: SocialMediaUtil.Site, formats: MutableList<Format>) {
        if (site == SocialMediaUtil.Site.X) {
            val isHttp = { f: Format -> f.format_id.startsWith("http-") }
            if (formats.any { it.format_id.startsWith("hls-") && it.vcodec.isNotBlank() && it.vcodec != "none" }) {
                formats.removeAll(isHttp)
            }
            return
        }
        if (site != SocialMediaUtil.Site.TIKTOK) return
        // (a list yt-dlp couldn't read at all, TikTok's HTTP 403, still gets the original)
        if (formats.isNotEmpty() && formats.none { it.vcodec.isNotBlank() && it.vcodec != "none" }) return
        if (formats.any { SocialMediaUtil.isTikTokOriginal(it.format_id) }) return
        formats.add(0, Format(
            format_id = SocialMediaUtil.TIKTOK_ORIGINAL_FORMAT_ID,
            container = "mp4",
            vcodec = "source",
            acodec = "aac",
            format_note = context.getString(R.string.original_source_quality)
        ))
    }

    fun readFormatsList(reader: JsonReader): ArrayList<Format> {
        val formats = arrayListOf<Format>()
        val seenFormatIds = HashSet<String>()

        reader.beginArray()
        while (reader.hasNext()) {
            val obj = readFormatObject(reader) // builds one JSONObject, keep-list filtered

            val id = obj.optString("format_id").ifBlank { obj.optString("itag") }
            if (id.isNotBlank() && !seenFormatIds.add(id)) {
                continue // duplicate - discard immediately, never converted to Format
            }

            val formatProper = parseOneFormat(obj) ?: continue
            formats.add(formatProper)
            // `obj` falls out of scope here - eligible for GC immediately,
            // nothing keeps N of them alive at once
        }
        reader.endArray()

        formats.reverse()
        return formats
    }

    private fun readFormatObject(reader: JsonReader): JSONObject {
        val obj = JSONObject()
        reader.beginObject()
        while (reader.hasNext()) {
            val name = reader.nextName()
            obj.put(name, readJsonValue(reader))
        }
        reader.endObject()
        return obj
    }

    private fun parseOneFormat(format: JSONObject): Format? {
        runCatching {
            if (format.get("filesize").toString() == "None") format.remove("filesize")
        }
        runCatching {
            if (format.get("filesize_approx").toString() == "None") format.remove("filesize_approx")
        }

        val exactSize = format.optLong("filesize").takeIf { it > 0L }
        val reportedApprox = format.optLong("filesize_approx").takeIf { it > 0L }

        runCatching {
            if (format.get("format_note").toString() == "null") format.remove("format_note")
        }

        val formatProper = Gson().fromJson(format.toString(), Format::class.java)
        if (formatProper.format_note == null) formatProper.format_note = ""

        formatProper.filesize = exactSize ?: reportedApprox ?: 0
        formatProper.isFilesizeApprox = exactSize == null

        val resolution = format.optString("resolution")
        if (format.has("format_note")) {
            if (!formatProper.format_note.contains("audio only", true)) {
                formatProper.format_note = format.getString("format_note")
            } else {
                if (!formatProper.format_note.endsWith("audio", true)) {
                    formatProper.format_note = format.getString("format_note").uppercase().removeSuffix("AUDIO").trim() + " AUDIO"
                }
            }
            if (!resolution.isNullOrBlank() && resolution != "audio only") {
                formatProper.format_note = "${formatProper.format_note} (${resolution})"
            }
        }

        if (formatProper.format_note.contains("storyboard", ignoreCase = true)) return null

        formatProper.format_note = formatProper.format_note.trim()
        formatProper.container = format.getString("ext")
        if (formatProper.tbr == "None") formatProper.tbr = ""
        if (!formatProper.tbr.isNullOrBlank()) {
            formatProper.tbr += "k"
        }

        if (formatProper.vcodec.isNullOrEmpty() || formatProper.vcodec == "null") {
            if (formatProper.acodec.isNullOrEmpty() || formatProper.acodec == "null") {
                formatProper.vcodec = format.getStringByAny("video_ext", "ext").ifEmpty { "unknown" }
            }
        }

        return formatProper
    }


    private fun parseYTDLFormats(formatsInJSON: JSONArray?) : ArrayList<Format> {
        val formats = arrayListOf<Format>()

        if (formatsInJSON != null) {
            for (f in formatsInJSON.length() - 1 downTo 0){
                val formatRaw = formatsInJSON.getJSONObject(f)
                val format = parseOneFormat(formatRaw) ?: continue
                formats.add(format)
            }
        }
        return formats
    }


    suspend fun getStreamingUrlAndChapters(url: String) : Result<Pair<List<String>, List<ChapterItem>?>> {
        try {
            val request = YTDLRequest(url)
            //request.addOption("--get-url")
            request.addOption("--print", "%(.{urls,chapters})s")
            request.addOption("-S", "res:720,+proto:m3u8")
            request.applyDefaultOptionsForFetchingData(url)
            if (url.isYoutubeURL()) {
                request.setYoutubeExtractorArgs(url)
            }

            val ytdlResponse = RuntimeManager.getInstance().runKillable { processId ->
                RuntimeManager.getInstance().execute(request, processId)
            }
            val json = JSONObject(ytdlResponse.out)
            val urls = if (json.has("urls")) {
                json.getString("urls").split("\n")
            }else{
                listOf()
            }

            val chapters = if (json.has("chapters")) {
                val arr = json.getJSONArray("chapters")
                val list = mutableListOf<ChapterItem>()
                for (i in 0 until arr.length()) {
                    list.add(
                        Gson().fromJson(arr.getJSONObject(i).toString(), ChapterItem::class.java)
                    )
                }

                list
            }else{
                listOf()
            }

            return Result.success(Pair(urls, chapters))

        } catch (e: Exception) {
            if (e is CancellationException) throw e
            return Result.failure(e)
        }
    }
    fun getVersion(context: Context, channel: String) : String {
        val prefVersion = if (listOf("stable", "nightly", "master").contains(channel)) {
            RuntimeManager.getInstance().version(context) ?: ""
        } else ""

        if (prefVersion.isNotBlank()) return prefVersion

        val req = YTDLRequest(emptyList())
        req.addOption("--version")
        return RuntimeManager.getInstance().execute(req).out.trim()
    }

    @OptIn(ExperimentalStdlibApi::class)
    private fun YTDLRequest.addWriteInfoJson(url: String) {
        if (url.isYoutubeURL() && url.contains("playlist?list=")) return

        val cachePath = FileUtil.getInfoJsonPath(context)
        File(cachePath).mkdirs()

        var id = url
        if (url.isYoutubeURL()) {
            id = url.getIDFromYoutubeURL() ?: url
        }

        val infoJsonName = hash(id)
        //yt-dlp doesnt overwrite info json, so delete manually
        File("${cachePath}/${infoJsonName}video.info.json").delete()
        this.addOption("--no-clean-info-json")
        this.addCommands(listOf("--print-to-file", "video:%()j", "${cachePath}/${infoJsonName}${System.currentTimeMillis()}video.info.json"))
    }

    fun hash(text: String): String {
        val crc = CRC32()
        crc.update(text.toByteArray())
        return crc.value.toString(16) // 8 hex chars max
    }

    @OptIn(ExperimentalStdlibApi::class)
    private fun getInfoJsonFile(url: String): File? {
        val cachePath = FileUtil.getInfoJsonPath(context)

        var id = url
        if (url.isYoutubeURL()) {
            id = url.getIDFromYoutubeURL() ?: url
        }

        val infoJsonName = hash(id)
        val infoJsonFile : File? =
            File(cachePath)
                .walkBottomUp()
                .sortedByDescending { it.lastModified() }
                .filter { it.name.startsWith(infoJsonName) }
                .firstOrNull()

        return infoJsonFile
    }

    fun getFilenameTemplatePreview(item: DownloadItem, filenameTemplate: String): String {
        item.customFileNameTemplate = filenameTemplate
        val request = buildYTDLRequest(item)
        request.addOption("--print", "%(filename)s")
        request.addOption("--skip-download")
        request.addOption("--simulate")
        request.addOption("--no-check-formats")
        request.addOption("--quiet")

        try {
            val response = RuntimeManager.getInstance().execute(request)
            return response.out.replace(FileUtil.getCacheDownloadsPath(context) + "/${item.id}/", "").trim()
        } catch (ex: Exception) {
            return ex.message ?: ""
        }
    }

    fun parseYTDLRequestString(request : YTDLRequest) : String {
        val arr = request.buildCommand().toMutableList()
        for (i in arr.indices) {
            if (!arr[i].startsWith("-")) {
                arr[i] = "\"${arr[i]}\""
            }
        }

        var final = java.lang.String.join(" ", arr).replace("\"\"", "\" \"")
        val ppas = "--config(-locations)? \"(.*?)\"".toRegex().findAll(final)
        ppas.forEach {res ->
            val path = "\"(.*?)\"".toRegex().find(res.value)?.value?.replace("\"", "")
            val newVal = runCatching {
                File(path ?: "").readText()
            }.onFailure {
                res.value
            }.getOrDefault("")

            final = final.replace(res.value, newVal)

        }

        return final
    }

    private fun MutableList<String>.addOption(vararg options: String) {
        options.forEach {
            this.add(it)
        }
    }


    private fun YTDLRequest.setYoutubeExtractorArgs(url: String?) {
        val extractorArgs = mutableListOf<String>()
        val playerClients = mutableSetOf<String>()
        val poTokens = mutableListOf<String>()

        val configuredPlayerClientsRaw = sharedPreferences.getString("youtube_player_clients", "[]")!!.ifEmpty { "[]" }
        kotlin.runCatching {
            val configuredPlayerClients = Gson().fromJson(configuredPlayerClientsRaw, Array<YoutubePlayerClientItem>::class.java).toMutableList()

            for (value in configuredPlayerClients) {
                if (value.enabled) {
                    if (!value.useOnlyPoToken) {
                        playerClients.add(value.playerClient)
                    }

                    var canUsePoToken = true
                    if (value.urlRegex.isNotEmpty() && url != null) {
                        canUsePoToken = value.urlRegex.any { url.matches(it.toRegex()) }
                    }

                    if (canUsePoToken) {
                        value.poTokens.forEach { pt ->
                            poTokens.add("${value.playerClient}.${pt.context}+${pt.token}")
                        }
                    }
                }
            }
        }

//        val dataSyncID = sharedPreferences.getString("youtube_data_sync_id", "")!!
//        if (dataSyncID.isNotBlank()) {
//            extractorArgs.add("player_skip=webpage,configs")
//            extractorArgs.add("data_sync_id=${dataSyncID}")
//        }

        val generatedPoTokensRaw = sharedPreferences.getString("youtube_generated_po_tokens", "[]")!!.ifEmpty { "[]" }
        kotlin.runCatching {
            val generatedPoTokens = Gson().fromJson(generatedPoTokensRaw,Array<YoutubeGeneratePoTokenItem>::class.java).toMutableList()
            if (generatedPoTokens.isNotEmpty()) {
                for (value in generatedPoTokens) {
                    if (value.enabled) {
                        for (cl in value.clients) {
                            playerClients.add(cl)
                            for (pt in value.poTokens) {
                                if (pt.token.isNotBlank()) {
                                    poTokens.add("${cl}.${pt.context}+${pt.token}")
                                }
                            }
                        }

//                        if (dataSyncID.isBlank() && value.useVisitorData) {
//                            extractorArgs.add("player_skip=webpage,configs")
//                            extractorArgs.add("visitor_data=${value.visitorData}")
//                        }

                    }
                }
            }
        }

        if (playerClients.isNotEmpty()){
            extractorArgs.add("player_client=${playerClients.joinToString(",")}")
        }else{
            //TODO DISCUSS
            //extractorArgs.add("player_client=default,-web,-web-safari,-android,-ios,-tv")
        }

        if (poTokens.isNotEmpty() && sharedPreferences.getBoolean("use_cookies", false)) {
            extractorArgs.add("po_token=${poTokens.joinToString(",")}")
        }

        //extractorArgs.add("skip=translated_subs")

        val useLanguageForMetadata = sharedPreferences.getBoolean("use_app_language_for_metadata", false)
        if (useLanguageForMetadata) {
            val lang = java.util.Locale.getDefault().language
            val langTag = java.util.Locale.getDefault().toLanguageTag()
            if (context.getStringArray(R.array.subtitle_langs).contains(lang)) {
                extractorArgs.add("lang=$lang")
            }else if (context.getStringArray(R.array.subtitle_langs).contains(langTag)) {
                extractorArgs.add("lang=$langTag")
            }
        }

        val otherArgs = sharedPreferences.getString("youtube_other_extractor_args", "")!!
        if (otherArgs.isNotBlank()) {
            extractorArgs.add(otherArgs)
        }

        val extArgs = extractorArgs.joinToString(";")
        if (extractorArgs.isNotEmpty()) {
            this.addOption("--extractor-args", "youtube:${extArgs}")
        }

        val useBgUtils = sharedPreferences.getBoolean("use_bgutils_potoken_generator", false)
        val bgUtilsMethod = sharedPreferences.getString("bgutils_potoken_method", "server")
        if (useBgUtils && bgUtilsMethod == "generation_script") {
            val serverPath = File(BgUtilsPoTokenGeneratorUtil.getServerFolder(context), "server").absolutePath
            this.addOption("--extractor-args", "youtubepot-bgutilscript:server_home=${serverPath}")
        }
    }

    private fun YTDLRequest.addConfig(commandString: String) {
        this.addOption(
            "--config-locations",
            File(context.cacheDir.absolutePath + "/${System.currentTimeMillis()}${java.util.UUID.randomUUID()}.txt").apply {
                writeText(commandString)
            }.absolutePath
        )
    }

    private fun StringJoiner.addOption(vararg elements: Any) {
        this.add(elements.first().toString())
        if (elements.size > 1) {
            for (el in elements.drop(1)) {
                val arg = el.toString()
                    //.replace("\\", "\\\\")
                    .replace("\"", "\\\"")

                this.add("\"$arg\"")
            }
        }
    }

    /** [sourceUrl]: a direct link to download instead of the item's url, like a TikTok original. */
    @SuppressLint("RestrictedApi")
    fun buildYTDLRequest(downloadItem: DownloadItem, sourceUrl: String? = null) : YTDLRequest {
        var useItemURL = sharedPreferences.getBoolean("use_itemurl_instead_playlisturl", false)
        // for /releases youtube channel playlists that have playlists inside of them, cant use indexing or match filter id, so download on its own
        if (downloadItem.url.isYoutubeURL() && downloadItem.url.getIDFromYoutubeURL() == null) {
            useItemURL = true
        }

        var isPlaylistItem = false

        val request = StringJoiner(" ")

        val ytDlRequest = if (!sourceUrl.isNullOrBlank()) {
            YTDLRequest(sourceUrl)
        }else if (downloadItem.url.endsWith(".txt")) {
            YTDLRequest(listOf()).apply {
                request.addOption("-a", downloadItem.url)
            }
        }else if (downloadItem.playlistURL.isNullOrBlank() || downloadItem.playlistTitle.isBlank() || useItemURL){
            if (downloadItem.url.isBlank()) {
                YTDLRequest(listOf())
            }else{
                YTDLRequest(downloadItem.url)
            }
        }else{
            isPlaylistItem = true
            YTDLRequest(downloadItem.playlistURL!!).apply {
                val ytVideoID = downloadItem.url.getIDFromYoutubeURL()
                if(downloadItem.playlistIndex == null || (downloadItem.url.isYoutubeURL() && ytVideoID != null)){
                    request.addOption("--match-filter", "id~='${ytVideoID}'")
                }else{
                    request.addOption("-I", "${downloadItem.playlistIndex!!}")
                }
            }
        }

        request.addOption("--newline")
        request.addOption("--plugin-dirs", FileUtil.getBundledYTDLPPluginsPath(context))

        val metadataCommands = StringJoiner(" ")

        if (downloadItem.playlistIndex != null && useItemURL) {
            metadataCommands.addOption("--parse-metadata", " ${downloadItem.playlistIndex}: %(playlist_index)s")
        }

        if (downloadItem.playlistTitle.isNotBlank() && useItemURL) {
            metadataCommands.addOption("--parse-metadata", " :%(playlist_title)s")
            metadataCommands.addOption("--parse-metadata", "%(playlist_title)s:%(playlist)s")
            metadataCommands.addOption("--replace-in-metadata", "playlist,playlist_title", "^.*$", downloadItem.playlistTitle)
        }

        if (downloadItem.playlistIndex != null) {
            metadataCommands.addOption("--parse-metadata", "%(playlist_index)s:playlist_index")
        }

        downloadItem.rowNumber.apply {
            if (this > 0) {
                request.addOption("--parse-metadata", " ${downloadItem.rowNumber}: %(rownumber)s")
            }
        }

        val type = downloadItem.type

        val targetDir = File(FileUtil.formatPath(downloadItem.downloadPath))
        val cacheDownloads = sharedPreferences.getBoolean("cache_downloads", true)
        val writtenPath = type == DownloadType.command && downloadItem.format.format_note.contains("-P ")

        val writeDirectly = writtenPath || (!cacheDownloads && targetDir.canWrite())
        val downDir: File
        if (writeDirectly) {
            downDir = targetDir
            request.addOption("--no-quiet")
            request.addOption("--no-simulate")
            request.addOption("--print", "after_move:'%(filepath,_filename)s'")
        } else {
            downDir = File(FileUtil.getCacheDownloadsPath(context), downloadItem.id.toString()).apply {
                deleteRecursively()
                mkdirs()
            }
        }

        // YTindir: aria2c is not shipped, yt-dlp always uses its own downloader

        val concurrentFragments = sharedPreferences.getInt("concurrent_fragments", 1)
        if (concurrentFragments > 1) request.addOption("-N", concurrentFragments)

        val retries = sharedPreferences.getString("retries", "")!!
        val fragmentRetries = sharedPreferences.getString("fragment_retries", "")!!

        if(retries.isNotEmpty()) request.addOption("--retries", retries)
        if(fragmentRetries.isNotEmpty()) request.addOption("--fragment-retries", fragmentRetries)

        val limitRate = sharedPreferences.getString("limit_rate", "")!!
        if (limitRate.isNotBlank()) request.addOption("-r", limitRate)

        val bufferSize = sharedPreferences.getString("buffer_size", "")!!
        if (bufferSize.isNotBlank()){
            request.addOption("--buffer-size", bufferSize)
            request.addOption("--no-resize-buffer")
        }

        val socketTimeout = sharedPreferences.getString("socket_timeout", "")!!
        if (socketTimeout.isNotBlank()) {
            request.addOption("--socket-timeout", socketTimeout)
        }

        if (sharedPreferences.getBoolean("restrict_filenames", true)) request.addOption("--restrict-filenames")
        if (sharedPreferences.getBoolean("force_ipv4", false)){
            request.addOption("-4")
        }
        if (useCookiesFor(downloadItem.url)){
            FileUtil.getCookieFile(context){
                request.addOption("--cookies", it)
            }
        }

        if (sharedPreferences.getBoolean("no_check_certificates", false) && !request.toString().contains("--no-check-certificates")) {
            request.addOption("--no-check-certificates")
        }

        val proxy = sharedPreferences.getString("proxy", "")
        if (proxy!!.isNotBlank()){
            request.addOption("--proxy", proxy)
        }

        val keepCache = sharedPreferences.getBoolean("keep_cache", false)
        if(keepCache){
            request.addOption("--keep-fragments")
        }

        val embedMetadata = sharedPreferences.getBoolean("embed_metadata", true)
        val thumbnailFormat = sharedPreferences.getString("thumbnail_format", "jpg")
        var filenameTemplate = downloadItem.customFileNameTemplate
        // YTindir: the cleaned title and author go straight into the file name (no | / , or emojis)
        if (downloadItem.type != DownloadType.command && sharedPreferences.getBoolean("clean_filenames", true)) {
            // never let file name cleaning stop a download
            filenameTemplate = runCatching {
                FileNameCleaner.fillTemplate(filenameTemplate, downloadItem.title, downloadItem.author)
            }.getOrDefault(filenameTemplate)
        }
        // YTindir: a quick download that starts before the post was read has no title yet; Instagram,
        // X, TikTok and Facebook still get "username_postid" (not "Video by …" or a whole tweet)
        if (downloadItem.type != DownloadType.command && downloadItem.title.isBlank()) {
            SocialMediaUtil.outputTitleTemplate(downloadItem.url)?.let {
                filenameTemplate = FileNameCleaner.replaceTitleField(filenameTemplate, it)
            }
        }

        if(downloadItem.type != DownloadType.command){
            if (sharedPreferences.getBoolean("no_part", false)){
                request.addOption("--no-part")
            }

            if (sharedPreferences.getBoolean("trim_filenames", true)) {
                request.addOption("--trim-filenames",  254 - downDir.absolutePath.length)
            }

            if (downloadItem.SaveThumb) {
                request.addOption("--write-thumbnail")
                request.addOption("--convert-thumbnails", thumbnailFormat!!)
            }
            if (!sharedPreferences.getBoolean("mtime", false)){
                request.addOption("--no-mtime")
            }else{
                request.addOption("--mtime")
            }

            val sponsorBlockFilters : ArrayList<String> = when(downloadItem.type) {
                DownloadType.audio -> {
                    downloadItem.audioPreferences.sponsorBlockFilters
                }
                //video
                else -> {
                    downloadItem.videoPreferences.sponsorBlockFilters
                }
            }


            if (sharedPreferences.getBoolean("use_sponsorblock", true)){
                if (sponsorBlockFilters.isNotEmpty()) {
                    val filters = java.lang.String.join(",", sponsorBlockFilters.filter { it.isNotBlank() })
                    if (filters.isNotBlank()) {
                        request.addOption("--sponsorblock-remove", filters)
                        if (sharedPreferences.getBoolean("force_keyframes", false)){
                            request.addOption("--force-keyframes-at-cuts")
                        }
                    }
                }
            }

            if(downloadItem.title.isNotBlank()){
                metadataCommands.addOption("--replace-in-metadata", "title", """^.*$""", downloadItem.title.replace("""\""", """\\"""))
                metadataCommands.addOption("--parse-metadata", "%(title)s:%(meta_title)s")
            } else {
                // YTindir: a quick download's embedded title is "username_postid" too, like its file
                // name, not "Video by …"
                SocialMediaUtil.outputTitleTemplate(downloadItem.url)?.let {
                    metadataCommands.addOption("--parse-metadata", "$it:%(title)s")
                    metadataCommands.addOption("--parse-metadata", "%(title)s:%(meta_title)s")
                }
            }

            val useArtistTags = if (downloadItem.url.isYoutubeURL()) "artists,artist,creators," else ""
            metadataCommands.addOption("--parse-metadata", """%(${useArtistTags}uploader,channel,creator|)l:^(?P<uploader>.*?)(?:(?= - Topic)|$)""")

            if (downloadItem.author.isNotBlank()){
                metadataCommands.addOption("--replace-in-metadata", "uploader", """^.*$""", downloadItem.author.replace("""\""", """\\"""))
                metadataCommands.addOption("--parse-metadata", "%(uploader)s:%(artist)s")
            }

            if (downloadItem.downloadSections.isNotBlank()){
                val sections = downloadItem.downloadSections.split(";").filter { it.isNotBlank() }
                sections.forEach {
                    request.addOption("--download-sections", "*${it.split(" ")[0]}")
                }

                if (sections.isNotEmpty()) {
                    if (sharedPreferences.getBoolean("force_keyframes", false) && !request.toString().contains("--force-keyframes-at-cuts")){
                        request.addOption("--force-keyframes-at-cuts")
                    }
                }

                if (sections.size > 1){
                    filenameTemplate = "%(autonumber)d. $filenameTemplate [%(section_start>%H∶%M∶%S)s]"
                    if (downloadItem.mergeCuts) {
                        request.addOption("--use-postprocessor", "SectionMerge:when=post_process;count=${sections.size}")
                    }
                }
            }

            if (sharedPreferences.getBoolean("write_description", false)){
                request.addOption("--write-description")
            }

            if (downloadItem.url.isYoutubeURL()) {
                ytDlRequest.setYoutubeExtractorArgs(downloadItem.url)
            }

            /*
            * https://github.com/yt-dlp/yt-dlp/issues/11947
            * Cant use info json when using download sections
            * */
            val canUseWriteInfoJson =
                !sharedPreferences.getBoolean("disable_write_info_json", false) &&
                !request.toString().contains("--download-sections")

            if (canUseWriteInfoJson && downloadItem.playlistURL.isNullOrBlank()) {
                val infoJsonURL = downloadItem.url
                val infoJsonFile = getInfoJsonFile(infoJsonURL)
                //ignore info file if its older than 5 hours. puny measure to prevent expired formats in some cases
                if (infoJsonFile != null && System.currentTimeMillis() - infoJsonFile.lastModified() <= (1000 * 60 * 60 * 5)) {
                    request.addOption("--load-info-json", infoJsonFile.absolutePath)
                }else {
                    ytDlRequest.addWriteInfoJson(infoJsonURL)
                }
            }

            val subDirectories = sharedPreferences.getStringSet("save_subdirectory", setOf())!!
            if (subDirectories.contains("website")) {
                metadataCommands.addOption("--parse-metadata", "%(extractor_key,extractor,ie_key)s:^(?P<no_GH5ME>(?!Generic|HTML5MediaEmbed).*)$")
                metadataCommands.addOption("--parse-metadata", "%(no_GH5ME,webpage_url_domain)s:%(fldr_website)s")
            }
        }

        if (sharedPreferences.getString("prevent_duplicate_downloads", "")!! == "download_archive"){
            request.addOption("--download-archive", FileUtil.getDownloadArchivePath(context))
        }

        val internalPluginFFmpegPreset = sharedPreferences.getString("internal_plugin_ffmpeg_preset", "")

        val preferredAudioCodec = sharedPreferences.getString("audio_codec", "")!!
        val aCodecPrefIndex = context.getStringArray(R.array.audio_codec_values).indexOf(preferredAudioCodec)
        var aCodecPref = runCatching { context.getStringArray(R.array.audio_codec_values_ytdlp)[aCodecPrefIndex] }.getOrElse { "" }

        when(type){
            DownloadType.audio -> {
                val supportedContainers = context.resources.getStringArray(R.array.audio_containers)
                val preferredLanguage = sharedPreferences.getString("audio_language","")!!
                val formatImportance = formatUtil.getAudioFormatImportance(false)

                var abrSort = ""

                var audioQualityId : String = downloadItem.format.format_id
                if (audioQualityId.isBlank() || listOf("0", context.getString(R.string.best_quality), "ba", "best", "", context.getString(
                        R.string.worst_quality), "wa", "worst").contains(audioQualityId)){
                    audioQualityId = "ba/b"
                }else if(audioQualityId.contains("kbps_ytdlnisgeneric")){
                    abrSort = audioQualityId.split("kbps")[0]
                    audioQualityId = ""
                }else{
                    audioQualityId += "/ba/b"
                }

                if ((audioQualityId.isBlank() || audioQualityId == "ba/b") && formatImportance.contains("prefer_drc")) {
                    audioQualityId = "ba[format_id$=-drc]/${audioQualityId.ifEmpty { "ba/b" }}"
                }

                if ((audioQualityId.isBlank() || audioQualityId == "ba/b") && preferredLanguage.isNotBlank()) {
                    audioQualityId = "ba[language^=$preferredLanguage]/${audioQualityId.ifEmpty { "ba/b" }}"
                }

                if (audioQualityId.isNotBlank()) {
                    if (audioQualityId.matches(".*-[0-9]+.*".toRegex())) {
                        audioQualityId = if(!downloadItem.format.lang.isNullOrBlank() && downloadItem.format.lang != "None"){
                            "ba[format_id~='^(${audioQualityId.split("-")[0]})'][language^=${downloadItem.format.lang}]/ba/b"
                        }else{
                            "$audioQualityId/${audioQualityId.split("-")[0]}"
                        }
                    }

                    request.addOption("-f", audioQualityId)
                }

                request.addOption("-x")
                val ext = downloadItem.container

                val formatSorting = mutableListOf<String>()
                val useCustomFormatSorting = sharedPreferences.getBoolean("use_format_sorting", false)
                if (useCustomFormatSorting) {
                    formatSorting.add("hasaud")
                }

                for(order in formatImportance) {
                    when(order) {
                        "smallsize" -> {
                            formatSorting.add("+size")
                        }
                        "file_size" -> {
                            formatSorting.add("size")
                        }
//                        "language" -> {
//                            if (preferredLanguage.isNotBlank()) {
//                                formatSorting.add("lang:${preferredLanguage}")
//                            }
//                        }
                        "codec" -> {
                            if (aCodecPref.isNotBlank()){
                                formatSorting.add("acodec:$aCodecPref")
                            }
                        }
                        "container" -> {
                            if(ext.isNotBlank()){
                                if(!ext.matches("(webm)|(Default)|(${context.getString(R.string.defaultValue)})".toRegex()) && supportedContainers.contains(ext)){
                                    request.addOption("--audio-format", ext)
                                    formatSorting.add("aext:$ext")
                                }
                            }
                        }
                    }
                }

                if (downloadItem.format.format_id == context.resources.getString(R.string.worst_quality) || downloadItem.format.format_id == "wa" || downloadItem.format.format_id == "worst") {
                    formatSorting.remove("size")
                    formatSorting.remove("+size")
                    formatSorting.addAll(0,listOf("+abr"))
                }

                if (abrSort.isNotBlank()){
                    formatSorting.add(0, "abr:${abrSort}")
                }

                if (downloadItem.downloadSections.isNotBlank()) {
                    formatSorting.add(0, "proto:https")
                }

                if(formatSorting.isNotEmpty()) {
                    request.addOption("-S", formatSorting.joinToString(","))
                }

                request.addOption("-P", downDir.absolutePath)

                if (downloadItem.audioPreferences.splitByChapters && downloadItem.downloadSections.isBlank()){
                    request.addOption("--split-chapters")
                    request.addOption("-o", "chapter:%(section_number)d - %(section_title)s.%(ext)s")
                }else{
                    if (embedMetadata){
                        metadataCommands.addOption("--embed-metadata")

                        val emptyAuthor = downloadItem.author.isEmpty()
                        val usePlaylistMetadata = sharedPreferences.getBoolean("playlist_as_album", true)

                        if (emptyAuthor) {
                            if (usePlaylistMetadata) {
                                metadataCommands.addOption("--parse-metadata", "%(playlist_uploader,artist,uploader|)s:^(?P<first_artist>.*?)(?:(?=,\\s+)|$)")
                            }else{
                                metadataCommands.addOption("--parse-metadata", "%(artist,uploader|)s:^(?P<first_artist>.*?)(?:(?=,\\s+)|$)")
                            }
                        }else{
                            if (usePlaylistMetadata) {
                                metadataCommands.addOption("--parse-metadata", "%(playlist_uploader,artist|)s:^(?P<first_artist>.*?)(?:(?=,\\s+)|$)")
                            }else{
                                metadataCommands.addOption("--parse-metadata", "%(artist|)s:^(?P<first_artist>.*?)(?:(?=,\\s+)|$)")
                            }
                        }

                        if (usePlaylistMetadata) {
                            metadataCommands.addOption("--parse-metadata", "%(album,playlist_title,playlist|)s:%(meta_album)s")
                        }


                        metadataCommands.addOption("--parse-metadata", "%(album_artist,first_artist|)s:%(album_artist)s")
                        metadataCommands.addOption("--parse-metadata", "%(release_year,release_date>%Y,upload_date>%Y)s:(?P<meta_date>\\d+)")

                        if (isPlaylistItem) {
                            metadataCommands.addOption("--parse-metadata", "%(track_number,playlist_index)d:(?P<track_number>\\d+)")
                        }
                    }

                    val cropThumb = downloadItem.audioPreferences.cropThumb ?: sharedPreferences.getBoolean("crop_thumbnail", true)
                    if (downloadItem.audioPreferences.embedThumb){
                        metadataCommands.addOption("--embed-thumbnail")
                        if (!request.toString().contains("--convert-thumbnails")) metadataCommands.addOption("--convert-thumbnails", thumbnailFormat!!)

                        val thumbnailConfig = StringBuilder("")
                        val cropConfig = """-vf crop=\"'if(gt(ih,iw),iw,ih)':'if(gt(iw,ih),ih,iw)'\"""""
                        if (thumbnailFormat == "jpg")  thumbnailConfig.append("""--ppa "ThumbnailsConvertor:-qmin 1 -q:v 1"""")
                        if (cropThumb){
                            if (thumbnailFormat == "jpg") {
                                thumbnailConfig.deleteCharAt(thumbnailConfig.length - 1)
                                thumbnailConfig.append(""" $cropConfig""")
                            }
                            else thumbnailConfig.append("""--ppa "ThumbnailsConvertor:$cropConfig""")
                        }

                        if (thumbnailConfig.isNotBlank()){
                            request.addOption(thumbnailConfig.toString())
                        }

                    }

                    if (filenameTemplate.isNotBlank()){
                        request.addOption("-o", "${filenameTemplate.removeSuffix(".%(ext)s")}.%(ext)s")
                    }

                    //lyrics timing and duration only make sense for the full track
                    val audioPrefs = downloadItem.audioPreferences
                    if ((audioPrefs.embedLyrics || audioPrefs.saveLrc) && downloadItem.downloadSections.isBlank()) {
                        val args = mutableListOf(
                            //after_move so it runs once audio extraction, metadata and thumbnail are done
                            "when=after_move",
                            "embed=${if (audioPrefs.embedLyrics) 1 else 0}",
                            "lrc=${if (audioPrefs.saveLrc) 1 else 0}",
                            "offset=${audioPrefs.lyricsOffset}"
                        )
                        if (audioPrefs.lyricsId > 0) args.add("id=${audioPrefs.lyricsId}")
                        request.addOption("--use-postprocessor", "Lyrics:${args.joinToString(";")}")
                    }
                }

                if (downloadItem.audioPreferences.bitrate.isNotBlank()) {
                    request.addOption("--audio-quality", downloadItem.audioPreferences.bitrate)
                }

            }
            DownloadType.video -> {
                val supportedContainers = context.resources.getStringArray(R.array.video_containers)

                if (downloadItem.videoPreferences.addChapters && downloadItem.downloadSections.isBlank()) {
                    if (sharedPreferences.getBoolean("use_sponsorblock", true)){
                        request.addOption("--sponsorblock-mark", "all")
                    }
                    request.addOption("--embed-chapters")
                }

                if (embedMetadata) {
                    metadataCommands.add("--embed-metadata")
                }

                if (downloadItem.videoPreferences.writeSubs){
                    request.addOption("--write-subs")
                }

                if(downloadItem.videoPreferences.writeAutoSubs){
                    request.addOption("--write-auto-subs")
                }

                if (downloadItem.videoPreferences.embedSubs) {
                    if (sharedPreferences.getBoolean("no_keep_subs", false) && (downloadItem.videoPreferences.writeSubs || downloadItem.videoPreferences.writeAutoSubs)) {
                        request.addOption("--compat-options", "no-keep-subs")
                    }

                    request.addOption("--embed-subs")
                }

                if (downloadItem.videoPreferences.embedSubs || downloadItem.videoPreferences.writeSubs || downloadItem.videoPreferences.writeAutoSubs){
                    val subFormat = sharedPreferences.getString("sub_format", "")
                    if(subFormat!!.isNotBlank()){
                        request.addOption("--sub-format", "${subFormat}/best")
                        request.addOption("--convert-subtitles", subFormat)
                    }
                    request.addOption("--sub-langs", downloadItem.videoPreferences.subsLanguages.ifEmpty { ".*-orig" })
                }

                if (downloadItem.videoPreferences.burnSubs) {
                    request.addOption("--use-postprocessor", "BurnSubs:preset=$internalPluginFFmpegPreset")
                }

                var cont = ""
                val outputContainer = downloadItem.container

                if(
                    outputContainer.isNotEmpty() &&
                    outputContainer != "Default" &&
                    outputContainer != context.getString(R.string.defaultValue) &&
                    supportedContainers.contains(outputContainer)
                ){
                    cont = outputContainer

                    val cantRecode = listOf("avi")
                    if (downloadItem.videoPreferences.recodeVideo && !cantRecode.contains(cont)) {
                        request.addOption("--recode-video", outputContainer.lowercase())
                    }else if (!downloadItem.videoPreferences.compatibilityMode){
                        request.addOption("--merge-output-format", outputContainer.lowercase())
                    }

                    if (!listOf("webm", "avi", "flv", "gif").contains(outputContainer.lowercase())) {
                        if (downloadItem.videoPreferences.embedThumbnail) {
                            metadataCommands.addOption("--embed-thumbnail")
                            if (!request.toString().contains("--convert-thumbnails")) request.addOption("--convert-thumbnails", thumbnailFormat!!)
                        }
                    }
                }
                var acont = sharedPreferences.getString("audio_format", "")!!
                if (acont == "Default") acont = ""

                //format logic
                var videoF = downloadItem.format.format_id
                var altAudioF = ""
                var audioF = downloadItem.videoPreferences.audioFormatIDs.joinToString("+") { f ->
                    val format = downloadItem.allFormats.find { it.format_id == f }
                    format?.run {
                        if (this.format_id.matches(".*-[0-9]+".toRegex())) {
                            if (!this.lang.isNullOrBlank() && this.lang != "None") {
                                "ba[format_id~='^(${this.format_id.split("-")[0]})'][language^=${this.lang}]"
                            } else {
                                altAudioF = this.format_id.split("-")[0]
                                this.format_id
                            }
                        } else {
                            this.format_id
                        }
                    } ?: if (f == "wa") "" else f
                }.ifBlank { "ba" }
                val preferredAudioLanguage = sharedPreferences.getString("audio_language", "")!!
                val preferDRCAudio = sharedPreferences.getBoolean("prefer_drc_audio", false)
                val usingWorstAudio = downloadItem.videoPreferences.audioFormatIDs.any { it == "wa" }

                if (downloadItem.videoPreferences.removeAudio) audioF = ""

                var abrSort = ""
                if(audioF.contains("kbps_ytdlnisgeneric")){
                    abrSort = audioF.split("kbps")[0]
                    audioF = ""
                }

                val f = StringBuilder()

                val preferredCodec = sharedPreferences.getString("video_codec", "")
                val vCodecPrefIndex = context.getStringArray(R.array.video_codec_values).indexOf(preferredCodec)
                var vCodecPref = context.getStringArray(R.array.video_codec_values_ytdlp)[vCodecPrefIndex]

                // YTindir: H.264 re-encodes keep a quality close to the source (CRF 18) at a speed a
                // phone can manage (veryfast unless another preset is chosen), AAC at 192 kbps
                val recoderArgs = "CompatibleRecoder:preset=${internalPluginFFmpegPreset!!.ifBlank { "veryfast" }};crf=18;audio_bitrate=192k"
                if (downloadItem.videoPreferences.compatibilityMode) {
                    request.addOption("--merge-output-format", "mp4")
                    request.addOption("--remux-video", "mp4")
                    request.addOption("--use-postprocessor", recoderArgs)
                    vCodecPref = "h264"
                    aCodecPref = "aac"
                }

                // YTindir: an mp4 video gets AAC audio, the codec mp4 plays with everywhere;
                // the audio codec setting (e.g. Opus) is for audio downloads and other containers
                if (cont.equals("mp4", ignoreCase = true)) {
                    aCodecPref = "aac"
                    // the audio format setting (e.g. mp3) is the output of audio downloads, not a stream to look for
                    acont = "m4a"
                }

                val defaultFormats = context.resources.getStringArray(R.array.video_formats_values)
                val usingGenericFormat = defaultFormats.contains(videoF) || downloadItem.allFormats.isEmpty() || downloadItem.allFormats == formatUtil.getGenericVideoFormats(context.resources)
                var hasGenericResulutionFormat = ""
                if (!usingGenericFormat){
                    // with audio removed
                    if (audioF.isBlank()){
                        f.append("$videoF/bv/b")
                    }else{
                        //with audio
                        f.append("$videoF+$audioF/")
                        if (altAudioF.isNotBlank()){
                            f.append("$videoF+$altAudioF/")
                        }
                        if (!f.contains("$videoF+ba")) {
                            if (preferredAudioLanguage.isNotEmpty()) {
                                f.append("$videoF+ba[language^=$preferredAudioLanguage]/")
                            }else if (preferDRCAudio) {
                                f.append("$videoF+ba[format_id$=-drc]/")
                            }else {
                                f.append("$videoF+ba/")
                            }
                        }
                        f.append("$videoF/b")


                        if (audioF.count("+") > 0){
                            request.addOption("--audio-multistreams")
                        }
                    }
                }else{
                    if (videoF == context.resources.getString(R.string.best_quality) || videoF == "best" || videoF == context.resources.getString(
                            R.string.worst_quality) || videoF == "worst") {
                        videoF = "bv"
                    }else if (defaultFormats.contains(videoF)) {
                        hasGenericResulutionFormat = videoF.split("_")[0].dropLast(1)
                        videoF = "bv"
                    }

                    val preferredFormatIDs = sharedPreferences.getString("format_id", "").toString()
                        .split(",")
                        .filter { it.isNotEmpty() }
                        .ifEmpty { listOf(videoF) }.toMutableList()
                    if (!preferredFormatIDs.contains(videoF)){
                        preferredFormatIDs.add(0, videoF)
                    }
                    // ^ [videoF, preferredID1, preferredID2...]

                    val preferredAudioFormatIDs = sharedPreferences.getString("format_id_audio", "")
                        .toString()
                        .split(",")
                        .filter { it.isNotBlank() }
                        .ifEmpty {
                            val list = mutableListOf<String>()
                            if (preferredAudioLanguage.isNotEmpty() && !downloadItem.videoPreferences.removeAudio) list.add("ba[language^=$preferredAudioLanguage]")
                            if (preferDRCAudio) list.add("ba[format_id$=-drc]")
                            list
                        }.apply {

                        }.toMutableList()
                    if (!preferredAudioFormatIDs.contains(audioF) && audioF != "ba"){
                        preferredAudioFormatIDs.add(0, audioF)
                    }

                    if (preferredAudioFormatIDs.contains("wa")) {
                        preferredFormatIDs.remove("wa")
                    }

                    // ^ [audioF, preferredAID1, preferredAID2, ....]
                    if (preferredAudioFormatIDs.any{it.contains("+")}){
                        request.addOption("--audio-multistreams")
                    }


                    preferredFormatIDs.forEach { v ->
                        preferredAudioFormatIDs.filter { it.isNotBlank() }.forEach { a ->
                            f.append("$v+$a/")
                        }
                        //build format with just videoformatid and audio if remove audio is not checked
                        if (!downloadItem.videoPreferences.removeAudio){
                            //build format with audio with preferred language
                            if (preferredAudioLanguage.isNotBlank()){
                                val al = if (v == "wv"){
                                    "$v+wa[language^=$preferredAudioLanguage]/"
                                }else{
                                    "$v+ba[language^=$preferredAudioLanguage]/"
                                }
                                if (!f.contains(al)) f.append(al)
                            }
                            //build format with best audio
                            if (!f.contains("$v+ba/") && !f.contains("wa")) f.append("$v+ba/")
                            //build format with standalone video
                            if (v == "wv"){
                                f.append("w/")
                            }else{
                                if (v != "bv") f.append("$v/")
                            }
                        }
                    }

                    if(!f.endsWith("b/")){
                        //last fallback
                        if (f.isBlank()) {
                            f.append("bv/")
                        }

                        f.append("b")
                    }

                }

                val formatImportance = formatUtil.getVideoFormatImportance().toMutableList()
                val formatSorting = mutableListOf<String>()

                for(order in formatImportance) {
                    when(order) {
                        "smallsize" -> {
                            formatSorting.add("+size")
                        }
                        "file_size" -> {
                            formatSorting.add("size")
                        }
                        "no_audio" -> {
                            formatSorting.add("+hasaud")
                        }
                        "codec" -> {
                            if (vCodecPref.isNotBlank()) formatSorting.add("vcodec:$vCodecPref")
                            if (aCodecPref.isNotBlank()) formatSorting.add("acodec:$aCodecPref")
                        }
                        "resolution" -> {
                            if (hasGenericResulutionFormat.isNotBlank()) {
                                formatSorting.add("res:${hasGenericResulutionFormat}")
                            }
                        }
                        "container" -> {
                            if (!downloadItem.videoPreferences.compatibilityMode) {
                                if (cont.isNotBlank()) formatSorting.add("vext:$cont")
                                if (acont.isNotBlank()) formatSorting.add("aext:$acont")
                            }
                        }
                    }
                }
                // YTindir: after resolution, codec and container, take the highest frame rate the video has
                if (hasGenericResulutionFormat.isNotBlank()) formatSorting.add("fps")

                // YTindir: Instagram, X, TikTok, Facebook and VK get their best quality (yt-dlp's own order
                // already puts Instagram's dash first), not the resolution cap or codec
                val socialSite = SocialMediaUtil.siteOf(downloadItem.url)
                if (socialSite != null && usingGenericFormat) {
                    formatSorting.removeAll { it.startsWith("res:") || it.startsWith("vcodec:") || it.startsWith("vext:") || it == "fps" }
                }

                if (downloadItem.format.format_id == context.resources.getString(R.string.worst_quality) || downloadItem.format.format_id == "worst") {
                    formatSorting.remove("+size")
                    formatSorting.remove("size")
                    formatSorting.addAll(0, listOf("+br","+res","+fps"))
                }

                if (abrSort.isNotBlank()) {
                    formatSorting.add("abr:${abrSort}")
                } else if (usingWorstAudio) {
                    formatSorting.add("+abr")
                }

//                if (preferredLanguage.isNotBlank()) {
//                    formatSorting.add("lang:${preferredLanguage}")
//                }

                if (downloadItem.downloadSections.isNotBlank()) {
                    formatSorting.add(0, "proto:https")
                }

                if (formatSorting.isNotEmpty()) {
                    request.addOption("-S", formatSorting.joinToString(","))
                }

                var formatString = f.toString().replace("/$".toRegex(), "")
                // YTindir: without a chosen format, Facebook's best dash stream (not its "sd"/"hd" files)
                // and VK's best hls or dash stream (not its "url…" mp4 files)
                if (usingGenericFormat && !downloadItem.videoPreferences.removeAudio) {
                    when (socialSite) {
                        SocialMediaUtil.Site.FACEBOOK -> {
                            val plain = SocialMediaUtil.PLAIN_VIDEO_FILTER
                            formatString = "bv*[format_note*=DASH]$plain+ba/bv*[format_note*=DASH]+ba/b[format_note*=DASH]/$formatString"
                        }
                        // Instagram: H.264 / 8-bit VP9 first (its app API also has AV1 and HDR VP9)
                        SocialMediaUtil.Site.INSTAGRAM ->
                            formatString = "bv*${SocialMediaUtil.PLAIN_VIDEO_FILTER}+ba/$formatString"
                        SocialMediaUtil.Site.VK ->
                            formatString = "bv*[format_id!^=url][format_id!^=cache]+ba/b[format_id!^=url][format_id!^=cache]/$formatString"
                        else -> {}
                    }
                }
                if (downloadItem.downloadSections.isNotBlank()) {
                    // YTindir: cutting goes through ffmpeg, which often fails on HLS (m3u8) audio,
                    // so an https audio stream is tried first and the chosen one stays as fallback
                    val first = formatString.substringBefore("/")
                    if (first.contains("+")) {
                        val alt = first.substringBefore("+") + "+ba[protocol^=http]"
                        if (!formatString.startsWith("$alt/")) formatString = "$alt/$formatString"
                    }
                }
                // YTindir: X's http files fail to download; without a chosen format its best hls stream
                if (usingGenericFormat && SocialMediaUtil.siteOf(downloadItem.url) == SocialMediaUtil.Site.X) {
                    formatString = "bv*[format_id^=hls]+ba[format_id^=hls]/b[format_id^=hls]/$formatString"
                }
                request.addOption("-f", formatString)

                var copyStream = ""

                if (downloadItem.videoPreferences.cropValues.isNotBlank()){
                    val parts = downloadItem.videoPreferences.cropValues.split(":")
                    if (parts.size >= 6) {
                        val x = parts[0].toIntOrNull() ?: 0
                        val y = parts[1].toIntOrNull() ?: 0
                        val w = parts[2].toIntOrNull() ?: 0
                        val h = parts[3].toIntOrNull() ?: 0
                        val refW = parts[4].toIntOrNull() ?: 0
                        val refH = parts[5].toIntOrNull() ?: 0

                        if (w > 0 && h > 0) {
                            // YTindir: cropping re-encodes the video, always to H.264 (High profile, 8-bit
                            // 4:2:0) which every player opens, at a constant quality close to the source
                            // (CRF 20) instead of a bitrate; size and frame rate stay the source's and the
                            // audio is copied as it is (FFmpegCopyStream copies every stream it isn't told
                            // to re-encode)
                            val setting = "-c:v libx264 -profile:v high -pix_fmt yuv420p -crf 20 -preset fast"
                            copyStream = "$setting -vf crop=($w/$refW)*iw:($h/$refH)*ih:($x/$refW)*iw:($y/$refH)*ih"
                        }
                    }
                }

                if (downloadItem.videoPreferences.removeAudio && outputContainer != "gif") {
                    if (copyStream.isBlank()) {
                        copyStream = "-c copy"
                    }
                    copyStream = "$copyStream -an"
                }

                if (copyStream.isNotBlank()) {
                    request.addOption("--use-postprocessor", "FFmpegCopyStream")
                    request.addOption("--ppa", "CopyStream:$copyStream")
                }

                request.addOption("-P", downDir.absolutePath)

                if (downloadItem.videoPreferences.splitByChapters  && downloadItem.downloadSections.isBlank()){
                    request.addOption("--split-chapters")
                    request.addOption("-o", "chapter:%(section_number)d - %(section_title)s.%(ext)s")
                }else{
                    if (filenameTemplate.isNotBlank()){
                        request.addOption("-o", "${filenameTemplate.removeSuffix(".%(ext)s")}.%(ext)s")
                    }
                }

                if (downloadItem.videoPreferences.liveFromStart) {
                    request.addOption("--live-from-start")
                }

                downloadItem.videoPreferences.waitForVideoMinutes.apply {
                    if (this > 0) {
                        request.addOption("--wait-for-video", this * 60)
                    }
                }

            }
            DownloadType.command -> {
                if (!writtenPath) {
                    request.addOption("-P", downDir.absolutePath)
                }

                request.addOption(downloadItem.format.format_note)
            }

            else -> {}
        }

        request.merge(metadataCommands)

        if (downloadItem.extraCommands.isNotBlank() && downloadItem.type != DownloadType.command){
            request.addOption(downloadItem.extraCommands)
        }

        if (request.toString().contains("sponsorblock")) {
            val sponsorBlockURL = sharedPreferences.getString("sponsorblock_url", "")!!
            if (sponsorBlockURL.isNotBlank()) request.addOption("--sponsorblock-api", sponsorBlockURL)
        }

        val cache = File(FileUtil.getCacheDownloadsPath(context))
        cache.mkdirs()
        val conf = File(cache.absolutePath + "/${System.currentTimeMillis()}${UUID.randomUUID()}.txt")
        conf.createNewFile()
        conf.writeText(request.toString())
        val tmp = mutableListOf<String>()
        tmp.addOption("--config-locations", conf.absolutePath)
        ytDlRequest.addCommands(tmp)

        val ytdlpCache = File(FileUtil.getCacheYTDLPPath(context))
        ytDlRequest.addOption("--cache-dir", ytdlpCache.absolutePath)
        return ytDlRequest
    }

    companion object {
        const val INSTAGRAM_APP_API_ARGS = "instagram:app_id=ios"
        const val INSTAGRAM_IOS_USER_AGENT = "Instagram 361.0.0.35.82 (iPhone14,5; iOS 17_6; en_US; en; " +
            "scale=3.00; 1170x2532; 674117118) AppleWebKit/420+"
    }
}
