# VideoTürkmen Android

Bağımsız Kotlin / Jetpack Compose Android projesi. Paket adı: `com.videoturkmen.app`.

## Bu kaynak paketinde bulunanlar
- Koyu mor arayüz, ana sayfa, indirme merkezi, müzik/video kitaplığı ve ayarlar.
- HTTPS/HTTP doğrudan medya dosyası URL indirme; dosya uzantısı, şema, host, kullanıcı bilgisi ve port kontrolleri. HTTPS önerilir.
- Android DownloadManager üzerinden indirme kuyruğu, durum ve ilerleme görünümü; indirmeyi/kayıt girdisini kaldırma. Android DownloadManager gerçek duraklat/devam ettir API'si sunmadığı için bu kontrol bu sürümde yoktur.
- İndirilen tamamlanmış medya dosyalarını uygulama içi Media3 oynatıcıda oynatma. Format uyumluluğu cihaz/codec desteğine bağlıdır.
- Müzik ve video sekmeleri; yerel arama geçmişi ve özel arama modu. Arama şu an web aramasına yönlendirir.
- Android Keystore ile AES-256-GCM şifreli kopya oluşturma ve kullanıcı tarafından seçilen konuma geri çözme. Orijinal dosya silinmez.
- GitHub Actions ile debug APK artifact üretimi (`videoturkmen` dalı).

## Henüz tamamlanmayan kritik özellikler
Bu paket **YTindir ile özellik eşdeğeri, tamamlanmış bir sosyal medya indiricisi değildir**. YouTube, Instagram, TikTok, Facebook ve X/Twitter sayfa bağlantılarını çözen sağlayıcı motoru; kaynak içi arama; kalite/format seçenekleri; MP3 dönüştürme; gerçek pause/resume ve sağlayıcı bazlı hata yönetimi henüz yoktur. Şu an yalnızca URL'si doğrudan medya dosyasına işaret eden desteklenen dosyalar indirilebilir. Platformların erişim koşulları, oturum gereksinimleri, bölgesel engeller ve DRM kısıtları aşılmaz.

## Güvenlik ve gizlilik
- Uygulama yedeklemesi kapalı, cleartext HTTP trafiği kapalıdır. İndirme kodu HTTP'yi yalnızca açıkça verilen bağlantı için kabul eder; HTTPS tercih edilmelidir.
- Kasa anahtarı Android Keystore'da cihazla ilişkilidir. Uygulama kaldırılırsa, verileri temizlenirse veya Keystore anahtarı silinirse kasa dosyaları çözülemeyebilir. Kasa dosyalarını güvenli biçimde dışarı aktarmadan uygulamayı kaldırma/verileri temizleme.
- Kasa PIN/parola tabanlı taşınabilir kurtarma sunmaz.
- Uygulama şu an hesap girişi, reklam SDK'sı veya analitik/telemetri SDK'sı içermez.
- İndirme ve oynatma davranışı gerçek Android cihazda test edilmelidir.

## Bağımlılıklar ve lisans
Doğrudan eklenen AndroidX, Jetpack Compose ve AndroidX Media3 bileşenleri Apache License 2.0 lisanslı ekosistem bileşenleridir. Transitif bağımlılıkların kesin lisans dökümü, Gradle bağımlılık raporu ve lisans taraması başarılı derleme ortamında ayrıca üretilmelidir. Bu projede GPL-3.0 kaynak kodu veya yt-dlp/FFmpeg ikilisi bulunmaz.

## Derleme
- Android Studio / Gradle 8.9 / JDK 17
- Android Gradle Plugin 8.7.3, Kotlin 2.0.21
- `:app:assembleDebug`
- GitHub Actions workflow, `videoturkmen` dalına push veya manuel çalıştırma ile `VideoTurkmen-debug-apk` artifact üretir.

Bu çalışma ortamında Android SDK ve Gradle bağımlılıklarını internetten indirecek erişim bulunmadığından APK derlemesi doğrulanamamıştır. Kaynak paketinin APK'sı hazırmış gibi sunulmamaktadır.
