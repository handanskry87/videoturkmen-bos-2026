# VideoTürkmen – Bağımlılık ve güvenlik denetim notu

## Kaynak bağımsızlığı
Bu proje, YTindir/YTDLnis kaynak kodundan kopyalanmış bir uygulama değildir. GPL-3.0 lisanslı YTindir kaynak dosyaları, yt-dlp veya FFmpeg ikilisi bu projeye eklenmemiştir.

## Doğrudan beyan edilen bağımlılıklar
- AndroidX Activity / Lifecycle / Compose: Apache License 2.0 ailesi
- AndroidX Media3 ExoPlayer ve UI: Apache License 2.0
- Kotlin Gradle plugins ve Android Gradle Plugin: Apache License 2.0

Bu liste doğrudan eklenen ana bileşenleri özetler; transitif bağımlılıkların tam SBOM/lisans raporu, derleme ortamında Gradle dependency insight ve lisans taraması ile doğrulanmalıdır.

## Mevcut güvenlik önlemleri
- Uygulama yedeklemesi kapalı.
- Cleartext trafik varsayılan olarak kapalı.
- URL şeması, host, user-info, port ve dosya uzantısı doğrulanıyor.
- Dosya kasası AES-256-GCM ve Android Keystore kullanıyor.
- Reklam/analitik SDK'sı eklenmedi.

## Bilinen riskler / yapılması gereken doğrulamalar
- Android DownloadManager, harici servis davranışına bağlıdır; pause/resume kontrolü bu API ile sağlanmaz.
- Kasa anahtarı cihaz Keystore'una bağlıdır; veri temizleme/uygulama kaldırma sonrası kurtarma garantisi yoktur.
- Medya oynatma codec/format uyumluluğu cihazdan cihaza değişir.
- Sosyal platform çıkarıcıları entegre değildir; bu nedenle platform bağlantıları için güvenlik ve uyumluluk testi henüz yapılamaz.
- Gerçek cihazda APK kurulumu, indirme, oynatma, kasa round-trip testi ve statik analiz tamamlanmalıdır.
