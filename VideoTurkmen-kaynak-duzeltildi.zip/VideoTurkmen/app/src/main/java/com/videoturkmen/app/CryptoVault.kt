package com.videoturkmen.app

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec

/**
 * AES-256-GCM file encryption helper backed by Android Keystore.
 * Encrypted file format: 12-byte IV followed by authenticated ciphertext.
 * The UI can create encrypted copies and restore them to a user-selected destination.
 * The key is device-bound; uninstalling or clearing app data can make vault files unrecoverable.
 */
object CryptoVault {
    private const val STORE = "AndroidKeyStore"
    private const val ALIAS = "VideoTurkmen.FileEncryption.v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val IV_LENGTH = 12
    private const val TAG_BITS = 128

    private fun key(): java.security.Key {
        val store = KeyStore.getInstance(STORE).apply { load(null) }
        store.getKey(ALIAS, null)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, STORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    fun encryptFile(source: File, destination: File) {
        require(source.isFile && source.canRead()) { "Kaynak dosya okunamıyor." }
        require(source.absolutePath != destination.absolutePath) { "Kaynak ve hedef aynı olamaz." }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val iv = cipher.iv
        require(iv.size == IV_LENGTH) { "Beklenmeyen IV uzunluğu." }
        FileInputStream(source).use { input ->
            FileOutputStream(destination).use { output ->
                output.write(iv)
                javax.crypto.CipherOutputStream(output, cipher).use { encrypted ->
                    input.copyTo(encrypted)
                }
            }
        }
    }

    fun decryptFile(source: File, destination: File) {
        require(source.isFile && source.canRead()) { "Şifreli dosya okunamıyor." }
        require(source.absolutePath != destination.absolutePath) { "Kaynak ve hedef aynı olamaz." }
        FileInputStream(source).use { input ->
            val iv = ByteArray(IV_LENGTH)
            require(input.read(iv) == IV_LENGTH) { "Şifreli dosya biçimi geçersiz." }
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(TAG_BITS, iv))
            FileOutputStream(destination).use { output ->
                javax.crypto.CipherInputStream(input, cipher).use { decrypted ->
                    decrypted.copyTo(output)
                }
            }
        }
    }
}
