package com.videoturkmen.app

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay
import java.io.File
import java.net.URL

private val Bg = Color(0xFF090910)
private val Panel = Color(0xFF171522)
private val Purple = Color(0xFF9B5CFF)
private val Pink = Color(0xFFFF4FCB)
private val Muted = Color(0xFFAAA6B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VideoTurkmenApp(this) }
    }
}

private data class DownloadItem(val id: Long, val title: String, val status: Int, val downloaded: Long, val total: Long, val uri: String?)

@Composable
private fun VideoTurkmenApp(context: MainActivity) {
    var page by remember { mutableIntStateOf(0) }
    var url by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var privateSearch by remember { mutableStateOf(context.getSharedPreferences("videoturkmen", Context.MODE_PRIVATE).getBoolean("private_search", false)) }
    var history by remember { mutableStateOf(loadHistory(context)) }
    var downloads by remember { mutableStateOf(queryDownloads(context)) }
    var selectedTab by remember { mutableIntStateOf(1) }
    var message by remember { mutableStateOf("") }
    var showVault by remember { mutableStateOf(false) }
    var playerUri by remember { mutableStateOf<Uri?>(null) }
    var playerTitle by remember { mutableStateOf("") }
    
    LaunchedEffect(Unit) {
        while (true) { downloads = queryDownloads(context); delay(1200) }
    }
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) downloads = queryDownloads(context) }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Purple, secondary = Pink)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color(0xFF11101A)) {
                listOf("Ana Sayfa", "İndir", "Dosyalar", "Ayarlar").forEachIndexed { i, label ->
                    val icons = listOf(Icons.Default.Home, Icons.Default.Download, Icons.Default.Folder, Icons.Default.Settings)
                    NavigationBarItem(selected = page == i, onClick = { page = i }, icon = { Icon(icons[i], null) },
                        label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, indicatorColor = Color(0xFF302044), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().background(Bg).padding(padding).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Purple, Pink)), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.PlayArrow, null, tint = Color.White) }
                    Spacer(Modifier.width(10.dp)); Column { Text("VideoTürkmen", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold); Text("MEDYA MERKEZİN", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp) }
                    Spacer(Modifier.weight(1f)); IconButton(onClick = { showVault = true }) { Icon(Icons.Default.Lock, "Güvenlik kasası", tint = Purple) }
                }
                Spacer(Modifier.height(18.dp))
                when (page) {
                    0 -> {
                        Text("Medyan tek yerde.", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                        Text("Bağlantıdan indir, dosyalarını yönet ve oynat.", color = Muted)
                        Spacer(Modifier.height(18.dp))
                        GradientCard {
                            Text("HIZLI İNDİRME", color = Color(0xFFD8C4FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                            Spacer(Modifier.height(10.dp)); InputField(url, { url = it }, "Doğrudan medya bağlantısını yapıştır")
                            Spacer(Modifier.height(10.dp)); Button(onClick = { page = 1 }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("İndirme merkezine git") }
                        }
                        Spacer(Modifier.height(18.dp)); Text("HIZLI ERİŞİM", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Spacer(Modifier.height(10.dp)); Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            FeatureTile("Müzikler", Icons.Default.MusicNote, Modifier.weight(1f)) { page = 2; selectedTab = 0 }
                            FeatureTile("Videolar", Icons.Default.Movie, Modifier.weight(1f)) { page = 2; selectedTab = 1 }
                            FeatureTile("Kasa", Icons.Default.Lock, Modifier.weight(1f)) { showVault = true }
                        }
                        Spacer(Modifier.height(18.dp)); Text("AKTİF İNDİRMELER", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        downloads.filter { it.status == DownloadManager.STATUS_RUNNING || it.status == DownloadManager.STATUS_PENDING }.take(3).forEach { DownloadRow(it, context, onRemove = { removeDownload(context, it.id); downloads = queryDownloads(context) }) }
                    }
                    1 -> {
                        Text("İndirme merkezi", fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("Doğrudan medya URL'si gir veya web'de ara.", color = Muted)
                        Spacer(Modifier.height(14.dp)); InputField(url, { url = it }, "https://... medya dosyası bağlantısı")
                        Spacer(Modifier.height(8.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { if (search.isNotBlank()) { if (!privateSearch) { history = (history.filterNot { it == search } + search).takeLast(30); saveHistory(context, history) }; openSearch(context, search) } }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Search, null); Text("Web'de ara") }
                            OutlinedButton(onClick = { url = ""; search = "" }) { Text("Temizle") }
                        }
                        Spacer(Modifier.height(8.dp)); InputField(search, { search = it }, "Video / müzik adı")
                        Spacer(Modifier.height(12.dp)); Text("Desteklenen giriş: doğrudan MP4, WebM, MP3, M4A ve benzeri dosya URL'leri.", color = Muted, fontSize = 12.sp)
                        Text("Kalite seçimi ve MP3'e dönüştürme, platformun sunduğu ayrı medya akışlarına erişim gerektirir; bu sürüm bağlantıdaki dosyayı olduğu gibi indirir.", color = Color(0xFFFFC477), fontSize = 11.sp)
                        Spacer(Modifier.height(12.dp)); Button(onClick = {
                            val result = enqueueDownload(context, url.trim())
                            message = result
                            downloads = queryDownloads(context)
                        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("İndirmeyi başlat") }
                        if (message.isNotBlank()) Text(message, color = Color(0xFFFFC477), fontSize = 12.sp)
                        Spacer(Modifier.height(18.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Text("Arama geçmişi", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); TextButton(onClick = { history = emptyList(); saveHistory(context, history) }) { Text("Temizle", color = Pink) } }
                        if (history.isEmpty()) Text("Geçmiş boş.", color = Muted, fontSize = 12.sp) else history.asReversed().forEach { Text("⌕  $it", color = Muted, modifier = Modifier.fillMaxWidth().clickable { search = it }.padding(vertical = 5.dp), fontSize = 13.sp) }
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("Özel arama", fontWeight = FontWeight.SemiBold, fontSize = 13.sp); Text("Yeni aramaları geçmişe kaydetme", color = Muted, fontSize = 11.sp) }
                            Switch(checked = privateSearch, onCheckedChange = { privateSearch = it; context.getSharedPreferences("videoturkmen", Context.MODE_PRIVATE).edit().putBoolean("private_search", it).apply() })
                        }
                    }
                    2 -> {
                        Text("İndirilen dosyalar", fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Android İndirmeler klasöründe saklanır.", color = Muted)
                        Spacer(Modifier.height(12.dp)); TabRow(selectedTabIndex = selectedTab, containerColor = Bg, contentColor = Purple, divider = {}) { listOf("Müzikler", "Videolar").forEachIndexed { i, s -> Tab(selected = selectedTab == i, onClick = { selectedTab = i }, text = { Text(s) }, icon = { Icon(if (i == 0) Icons.Default.MusicNote else Icons.Default.Movie, null) }) } }
                        Spacer(Modifier.height(10.dp))
                        val filtered = downloads.filter { item -> val name = item.title.lowercase(); if (selectedTab == 0) name.endsWith(".mp3") || name.endsWith(".m4a") || name.endsWith(".aac") || name.endsWith(".wav") else !(name.endsWith(".mp3") || name.endsWith(".m4a") || name.endsWith(".aac") || name.endsWith(".wav")) }
                        if (filtered.isEmpty()) EmptyPanel("Dosya bulunamadı", "İndirdiğin dosyalar burada görünecek.") else LazyColumn { items(filtered, key = { it.id }) { item -> DownloadRow(item, context, true, onPlay = { uri -> playerUri = uri; playerTitle = item.title }, onRemove = { removeDownload(context, item.id); downloads = queryDownloads(context) }) } }
                    }
                    else -> {
                        Text("Ayarlar", fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("Gizlilik ve dosya güvenliği", color = Muted); Spacer(Modifier.height(14.dp))
                        SettingsRow("Güvenlik Kasası", "Dosyaları AES-256-GCM ile şifrele / çöz", Icons.Default.Lock) { showVault = true }
                        SettingsRow("Arama geçmişi", "Geçmişi temizle veya özel aramayı aç", Icons.Default.History) { page = 1 }
                        SettingsRow("İndirilenler", "Müzik ve video dosyaları", Icons.Default.Folder) { page = 2 }
                        Text("Sürüm 1.1.0 • VideoTürkmen", color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
    if (showVault) VaultDialog(context, onClose = { showVault = false })
    if (playerUri != null) MediaPlayerDialog(context, playerUri!!, playerTitle) { playerUri = null }
}

private fun enqueueDownload(context: Context, raw: String): String {
    return try {
        val uri = Uri.parse(raw.trim())
        require(uri.scheme.equals("https", true) || uri.scheme.equals("http", true)) { "Yalnızca http/https bağlantıları kabul edilir." }
        require(!uri.host.isNullOrBlank() && uri.userInfo == null) { "Bağlantı biçimi geçersiz." }
        require(uri.port == -1 || (uri.scheme.equals("https", true) && uri.port == 443) || (uri.scheme.equals("http", true) && uri.port == 80)) { "Bağlantı noktası şema ile uyumlu değil." }
        val rawName = uri.lastPathSegment?.substringBefore('?')?.substringBefore('#').orEmpty()
        require(rawName.isNotBlank()) { "Bu bir doğrudan dosya bağlantısı değil. Paylaşım/video sayfası bağlantıları henüz desteklenmiyor." }
        // Keep the destination inside the app's own Downloads subfolder; never trust URL path characters.
        val safeName = rawName.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").take(90)
        require(safeName.isNotBlank() && safeName != "." && safeName != "..") { "Dosya adı geçersiz." }
        val extension = safeName.substringAfterLast('.', "").lowercase()
        require(extension in setOf("mp4", "m4v", "mkv", "webm", "mov", "mp3", "m4a", "aac", "wav", "ogg", "flac", "opus", "ts", "3gp")) {
            "Dosya uzantısı tanınmıyor. MP4, WebM, MP3, M4A gibi doğrudan medya dosyası bağlantısı kullan."
        }
        val request = DownloadManager.Request(uri).setTitle(safeName).setDescription("VideoTürkmen indirmesi")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true).setAllowedOverRoaming(false)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "VideoTurkmen/$safeName")
        val id = (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
        val prefs = context.getSharedPreferences("vt_downloads", Context.MODE_PRIVATE)
        val ids = (prefs.getStringSet("ids", emptySet()) ?: emptySet()).toMutableSet().apply { add(id.toString()) }
        prefs.edit().putStringSet("ids", ids).apply()
        "İndirme kuyruğa eklendi. Bu sürüm doğrudan medya dosyası indirir; sosyal medya sayfası çözümleme ve kalite dönüştürme henüz ekli değil."
    } catch (e: Exception) { "İndirme başlatılamadı: ${e.message ?: "Bağlantıyı kontrol et."}" }
}

private fun queryDownloads(context: Context): List<DownloadItem> {
    val ids = context.getSharedPreferences("vt_downloads", Context.MODE_PRIVATE).getStringSet("ids", emptySet()) ?: emptySet()
    val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    return ids.mapNotNull { raw ->
        val id = raw.toLongOrNull() ?: return@mapNotNull null
        try {
            manager.query(DownloadManager.Query().setFilterById(id)).use { c ->
                if (!c.moveToFirst()) return@use null
                fun col(s: String) = c.getColumnIndex(s)
                val title = c.getString(col(DownloadManager.COLUMN_TITLE)) ?: "İndirilen dosya"
                DownloadItem(id, title, c.getInt(col(DownloadManager.COLUMN_STATUS)), c.getLong(col(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)), c.getLong(col(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)), c.getString(col(DownloadManager.COLUMN_LOCAL_URI)))
            }
        } catch (_: Exception) { null }
    }.sortedByDescending { it.id }
}

@Composable
private fun DownloadRow(
    item: DownloadItem,
    context: Context,
    allowOpen: Boolean = false,
    onPlay: ((Uri) -> Unit)? = null,
    onRemove: (() -> Unit)? = null
) {
    val status = when (item.status) {
        DownloadManager.STATUS_SUCCESSFUL -> "Tamamlandı"
        DownloadManager.STATUS_FAILED -> "Başarısız"
        DownloadManager.STATUS_PAUSED -> "Duraklatıldı"
        DownloadManager.STATUS_RUNNING -> "İndiriliyor"
        else -> "Bekliyor"
    }
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Panel, RoundedCornerShape(14.dp)).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.InsertDriveFile, null, tint = Purple)
            Spacer(Modifier.width(8.dp))
            Text(item.title, modifier = Modifier.weight(1f), fontSize = 12.sp, maxLines = 2)
            Text(status, color = Muted, fontSize = 10.sp)
        }
        if (item.total > 0) {
            Spacer(Modifier.height(7.dp))
            LinearProgressIndicator(progress = { (item.downloaded.toFloat() / item.total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Purple)
            Text("${(item.downloaded * 100 / item.total).coerceIn(0,100)}%", color = Muted, fontSize = 10.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (allowOpen && item.status == DownloadManager.STATUS_SUCCESSFUL) {
                TextButton(onClick = {
                    val uri = (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).getUriForDownloadedFile(item.id)
                    if (uri != null) onPlay?.invoke(uri) else openDownloaded(context, item.id)
                }) { Icon(Icons.Default.PlayArrow, null); Text("Oynat") }
            }
            if (item.status == DownloadManager.STATUS_FAILED) Text("İndirme başarısız; bağlantıyı kontrol edip yeniden ekle.", color = Color(0xFFFF9A9A), fontSize = 11.sp)
            Spacer(Modifier.weight(1f))
            if (onRemove != null) TextButton(onClick = onRemove) { Icon(Icons.Default.DeleteOutline, null, tint = Pink); Text("Kaldır", color = Pink) }
        }
    }
}

@Composable
private fun MediaPlayerDialog(context: Context, uri: Uri, title: String, onClose: () -> Unit) {
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    Dialog(onDismissRequest = onClose) {
        Column(Modifier.fillMaxWidth().background(Color(0xFF11101A), RoundedCornerShape(18.dp)).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, modifier = Modifier.weight(1f), maxLines = 1, fontWeight = FontWeight.Bold)
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Kapat") }
            }
            AndroidView(
                factory = { viewContext -> PlayerView(viewContext).apply { this.player = player; useController = true } },
                update = { it.player = player },
                modifier = Modifier.fillMaxWidth().height(220.dp)
            )
        }
    }
}

private fun removeDownload(context: Context, id: Long) {
    val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    manager.remove(id)
    val prefs = context.getSharedPreferences("vt_downloads", Context.MODE_PRIVATE)
    val ids = (prefs.getStringSet("ids", emptySet()) ?: emptySet()).toMutableSet()
    ids.remove(id.toString())
    prefs.edit().putStringSet("ids", ids).apply()
}

private fun openDownloaded(context: Context, id: Long) {
    val uri = (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).getUriForDownloadedFile(id) ?: return
    val mime = context.contentResolver.getType(uri) ?: "*/*"
    try { context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (_: Exception) { Toast.makeText(context, "Dosyayı açacak uygulama bulunamadı.", Toast.LENGTH_SHORT).show() }
}

private fun openSearch(context: Context, q: String) { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(q)}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
private fun loadHistory(c: Context) = c.getSharedPreferences("videoturkmen", Context.MODE_PRIVATE).getString("history", "")!!.split("\n").filter { it.isNotBlank() }
private fun saveHistory(c: Context, h: List<String>) { c.getSharedPreferences("videoturkmen", Context.MODE_PRIVATE).edit().putString("history", h.joinToString("\n")).apply() }

@Composable private fun VaultDialog(context: Context, onClose: () -> Unit) {
    var status by remember { mutableStateOf("Dosya seçerek AES-256-GCM ile şifreli kopya oluştur. Orijinal dosya silinmez.") }
    var busy by remember { mutableStateOf(false) }
    var selectedEncrypted by remember { mutableStateOf<File?>(null) }
    var vaultFiles by remember { mutableStateOf(context.filesDir.listFiles()?.filter { it.name.startsWith("vault_") && it.name.endsWith(".vte") }?.sortedByDescending { it.lastModified() } ?: emptyList()) }
    val encryptPicker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            try {
                val name = queryName(context, uri)
                val source = File(context.cacheDir, "vault_source.tmp")
                context.contentResolver.openInputStream(uri)!!.use { input -> source.outputStream().use { input.copyTo(it) } }
                val output = File(context.filesDir, "vault_${System.currentTimeMillis()}_${name}.vte")
                CryptoVault.encryptFile(source, output); source.delete()
                vaultFiles = context.filesDir.listFiles()?.filter { it.name.startsWith("vault_") && it.name.endsWith(".vte") }?.sortedByDescending { it.lastModified() } ?: emptyList()
                status = "Şifreli kopya oluşturuldu: ${output.name}. Orijinal dosya yerinde bırakıldı."
            } catch (e: Exception) { status = "Şifreleme başarısız: ${e.message}" }
            busy = false
        }
    }
    val decryptPicker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val source = selectedEncrypted
        if (uri != null && source != null) {
            busy = true
            try {
                val temp = File(context.cacheDir, "vault_decrypted.tmp")
                CryptoVault.decryptFile(source, temp)
                context.contentResolver.openOutputStream(uri)?.use { output -> temp.inputStream().use { it.copyTo(output) } }
                temp.delete()
                status = "Dosya seçtiğin konuma çözüldü."
            } catch (e: Exception) { status = "Şifre çözme başarısız: ${e.message}" }
            busy = false
            selectedEncrypted = null
        }
    }
    AlertDialog(onDismissRequest = onClose, containerColor = Panel, title = { Text("Güvenlik Kasası") }, text = {
        Column(Modifier.heightIn(max = 460.dp)) {
            Text("AES-256-GCM dosya şifreleme", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp)); Text(status, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Button(onClick = { encryptPicker.launch(arrayOf("*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Icon(Icons.Default.Lock, null); Spacer(Modifier.width(6.dp)); Text(if (busy) "İşleniyor..." else "Dosya seç ve şifrele") }
            Spacer(Modifier.height(12.dp)); Text("ŞİFRELİ DOSYALAR", color = Muted, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            if (vaultFiles.isEmpty()) Text("Henüz şifreli dosya yok.", color = Muted, fontSize = 12.sp)
            else LazyColumn(Modifier.heightIn(max = 150.dp)) {
                items(vaultFiles, key = { it.name }) { file ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.EnhancedEncryption, null, tint = Purple)
                        Spacer(Modifier.width(6.dp)); Text(file.name.take(28), modifier = Modifier.weight(1f), fontSize = 11.sp, maxLines = 1)
                        TextButton(onClick = { selectedEncrypted = file; decryptPicker.launch(file.name.removeSuffix(".vte")) }, enabled = !busy) { Text("Çöz") }
                    }
                }
            }
            Spacer(Modifier.height(8.dp)); Text("Anahtar Android Keystore'da bu cihaza bağlıdır. Uygulama verileri silinirse anahtar kaybolabilir; güvenli yedek almadan uygulamayı kaldırma.", color = Color(0xFFFFC477), fontSize = 10.sp)
        }
    }, confirmButton = { TextButton(onClick = onClose) { Text("Kapat") } })
}
private fun queryName(c: Context, uri: Uri): String {
    var name = "dosya"
    c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: name }
    return name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
}

@Composable private fun GradientCard(content: @Composable ColumnScope.() -> Unit) { Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF302044), Panel)), RoundedCornerShape(22.dp)).padding(17.dp), content = content) }
@Composable private fun InputField(value: String, onValueChange: (String) -> Unit, hint: String) { Row(Modifier.fillMaxWidth().background(Color(0xFF0D0C14), RoundedCornerShape(13.dp)).padding(horizontal = 13.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) { BasicTextField(value, onValueChange, modifier = Modifier.weight(1f), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 13.sp), decorationBox = { inner -> if (value.isEmpty()) Text(hint, color = Muted, fontSize = 12.sp); inner() }); Icon(Icons.Default.ContentPaste, null, tint = Purple, modifier = Modifier.size(18.dp)) } }
@Composable private fun FeatureTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) { Column(modifier.clickable(onClick = onClick).background(Panel, RoundedCornerShape(16.dp)).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = Purple, modifier = Modifier.size(24.dp)); Spacer(Modifier.height(6.dp)); Text(title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) } }
@Composable private fun EmptyPanel(title: String, detail: String) { Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.FolderOpen, null, tint = Purple, modifier = Modifier.size(38.dp)); Spacer(Modifier.height(9.dp)); Text(title, fontWeight = FontWeight.Bold); Text(detail, color = Muted, fontSize = 12.sp) } }
@Composable private fun SettingsRow(title: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) { Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Purple); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(detail, color = Muted, fontSize = 12.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Muted) } }
